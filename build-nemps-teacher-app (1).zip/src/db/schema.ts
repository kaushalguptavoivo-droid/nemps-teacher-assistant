import {
  pgTable,
  uuid,
  varchar,
  text,
  boolean,
  date,
  timestamp,
  integer,
  pgEnum,
  primaryKey,
  numeric,
} from "drizzle-orm/pg-core";

// ─── Enums ────────────────────────────────────────────────────────────
export const roleEnum = pgEnum("role", ["admin", "teacher"]);
export const attendanceStatusEnum = pgEnum("attendance_status", [
  "present",
  "absent",
]);
export const homeworkCompletionEnum = pgEnum("homework_completion", [
  "completed",
  "pending",
  "not_checked",
]);
export const feeStatusEnum = pgEnum("fee_status", ["paid", "due", "overdue"]);
export const noticeCategoryEnum = pgEnum("notice_category", [
  "Holiday",
  "Exam",
  "PTM",
  "Homework",
  "Circular",
  "General",
]);

// ─── Users / Profiles ────────────────────────────────────────────────
export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: varchar("email", { length: 255 }).unique().notNull(),
  passwordHash: text("password_hash").notNull(),
  displayName: varchar("display_name", { length: 255 }).notNull(),
  role: roleEnum("role").notNull().default("teacher"),
  phone: varchar("phone", { length: 20 }),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

// ─── Class Assignments ───────────────────────────────────────────────
export const classAssignments = pgTable("class_assignments", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id")
    .references(() => users.id, { onDelete: "cascade" })
    .notNull(),
  className: varchar("class_name", { length: 50 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ─── Students ────────────────────────────────────────────────────────
export const students = pgTable("students", {
  id: uuid("id").primaryKey().defaultRandom(),
  rollNo: varchar("roll_no", { length: 20 }).notNull(),
  studentName: varchar("student_name", { length: 255 }).notNull(),
  fatherName: varchar("father_name", { length: 255 }),
  motherName: varchar("mother_name", { length: 255 }),
  parentWhatsapp: varchar("parent_whatsapp", { length: 20 }),
  alternatePhone: varchar("alternate_phone", { length: 20 }),
  dob: date("dob"),
  address: text("address"),
  className: varchar("class_name", { length: 50 }).notNull(),
  photoUrl: text("photo_url"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

// ─── Attendance ──────────────────────────────────────────────────────
export const attendance = pgTable("attendance", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentId: uuid("student_id")
    .references(() => students.id, { onDelete: "cascade" })
    .notNull(),
  className: varchar("class_name", { length: 50 }).notNull(),
  attendanceDate: date("attendance_date").notNull(),
  status: attendanceStatusEnum("status").notNull(),
  markedBy: uuid("marked_by")
    .references(() => users.id, { onDelete: "set null" })
    .notNull(),
  remarks: text("remarks"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ─── Homework ────────────────────────────────────────────────────────
export const homework = pgTable("homework", {
  id: uuid("id").primaryKey().defaultRandom(),
  className: varchar("class_name", { length: 50 }).notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  homeworkDate: date("homework_date").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  createdBy: uuid("created_by")
    .references(() => users.id, { onDelete: "set null" })
    .notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ─── Homework Status ─────────────────────────────────────────────────
export const homeworkStatus = pgTable("homework_status", {
  id: uuid("id").primaryKey().defaultRandom(),
  homeworkId: uuid("homework_id")
    .references(() => homework.id, { onDelete: "cascade" })
    .notNull(),
  studentId: uuid("student_id")
    .references(() => students.id, { onDelete: "cascade" })
    .notNull(),
  status: homeworkCompletionEnum("status").notNull().default("not_checked"),
  checkedBy: uuid("checked_by").references(() => users.id, {
    onDelete: "set null",
  }),
  checkedAt: timestamp("checked_at", { withTimezone: true }),
  remarks: text("remarks"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

// ─── Fees ────────────────────────────────────────────────────────────
export const fees = pgTable("fees", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentId: uuid("student_id")
    .references(() => students.id, { onDelete: "cascade" })
    .notNull(),
  feeMonth: integer("fee_month").notNull(),
  feeYear: integer("fee_year").notNull(),
  monthlyFeeAmount: numeric("monthly_fee_amount", { precision: 10, scale: 2 }),
  examFeeAmount: numeric("exam_fee_amount", { precision: 10, scale: 2 }),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }),
  dueDate: date("due_date").notNull(),
  paidDate: date("paid_date"),
  status: feeStatusEnum("status").notNull().default("due"),
  reminderCount: integer("reminder_count").notNull().default(0),
  lastReminderAt: timestamp("last_reminder_at", { withTimezone: true }),
  remarks: text("remarks"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

// ─── Notices ─────────────────────────────────────────────────────────
export const notices = pgTable("notices", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 500 }).notNull(),
  body: text("body").notNull(),
  category: noticeCategoryEnum("category").notNull(),
  className: varchar("class_name", { length: 50 }),
  noticeDate: date("notice_date").notNull(),
  createdBy: uuid("created_by")
    .references(() => users.id, { onDelete: "set null" })
    .notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

// ─── Message Templates ───────────────────────────────────────────────
export const messageTemplates = pgTable("message_templates", {
  id: uuid("id").primaryKey().defaultRandom(),
  templateKey: varchar("template_key", { length: 100 }).unique().notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  bodyEn: text("body_en").notNull(),
  bodyHi: text("body_hi").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdBy: uuid("created_by")
    .references(() => users.id, { onDelete: "set null" })
    .notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});
