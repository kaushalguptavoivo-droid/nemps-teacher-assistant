// ─── School Info ──────────────────────────────────────────────────────
export const SCHOOL_NAME = "New Era Modern Public School, Vrindavan";
export const SCHOOL_SHORT_NAME = "NEMPS";
export const APP_NAME = "NEMPS Teacher Assistant";

// ─── Classes ─────────────────────────────────────────────────────────
export const CLASSES = [
  "Nursery",
  "Prep",
  "Pre1st",
  "1st",
  "2nd",
  "3rd",
  "4th",
  "5th",
  "6th",
  "7th",
  "8th",
] as const;

export type ClassName = (typeof CLASSES)[number];

// ─── Subjects ────────────────────────────────────────────────────────
export const SUBJECTS = [
  "Hindi",
  "English",
  "Math",
  "Science",
  "EVS",
  "SST",
  "Sanskrit",
  "Computer",
  "GK",
] as const;

export type SubjectName = (typeof SUBJECTS)[number];

// ─── Notice Categories ───────────────────────────────────────────────
export const NOTICE_CATEGORIES = [
  "Holiday",
  "Exam",
  "PTM",
  "Homework",
  "Circular",
  "General",
] as const;

export type NoticeCategory = (typeof NOTICE_CATEGORIES)[number];

// ─── Fee Constants ───────────────────────────────────────────────────
export const FEE_DUE_DAY = 7; // 7th of every month
export const FEE_OVERDUE_DAY = 15; // Overdue after 15th
export const EXAM_FEE_AMOUNT = 100; // INR
export const EXAM_FEE_MONTHS = [3, 9]; // March and September (2 times/year)

// ─── Months ──────────────────────────────────────────────────────────
export const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
] as const;

// ─── Template Keys ───────────────────────────────────────────────────
export const TEMPLATE_KEYS = [
  "absent_student",
  "homework_pending",
  "fee_due",
  "general_notice",
  "ptm_notice",
] as const;

export type TemplateKey = (typeof TEMPLATE_KEYS)[number];

// ─── WhatsApp ────────────────────────────────────────────────────────
export const WHATSAPP_URL = "https://wa.me/";
export const WHATSAPP_WEB_URL = "https://web.whatsapp.com/send?";
