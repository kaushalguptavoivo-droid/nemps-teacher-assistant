import { SignJWT, jwtVerify } from "jose";
import { compare, hash } from "bcryptjs";

// ─── Config ──────────────────────────────────────────────────────────
const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || "nemps-teacher-assistant-secret-key-2024"
);
const COOKIE_NAME = "nemps_session";
const TOKEN_EXPIRY = "7d";

// ─── Types ───────────────────────────────────────────────────────────
export interface SessionPayload {
  userId: string;
  email: string;
  role: "admin" | "teacher";
  displayName: string;
}

// ─── Password Helpers ────────────────────────────────────────────────
export async function hashPassword(password: string): Promise<string> {
  return hash(password, 12);
}

export async function verifyPassword(
  password: string,
  hashed: string
): Promise<boolean> {
  return compare(password, hashed);
}

// ─── JWT Helpers ─────────────────────────────────────────────────────
export async function createToken(payload: SessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(TOKEN_EXPIRY)
    .sign(JWT_SECRET);
}

export async function verifyToken(
  token: string
): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return {
      userId: payload.userId as string,
      email: payload.email as string,
      role: payload.role as "admin" | "teacher",
      displayName: payload.displayName as string,
    };
  } catch {
    return null;
  }
}

// ─── Cookie Helpers (for API routes) ─────────────────────────────────
export function getSessionCookieName(): string {
  return COOKIE_NAME;
}

export function createSessionCookie(token: string) {
  return {
    name: COOKIE_NAME,
    value: token,
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: 60 * 60 * 24 * 7, // 7 days
  };
}

export function createLogoutCookie() {
  return {
    name: COOKIE_NAME,
    value: "",
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    path: "/",
    maxAge: 0,
  };
}
