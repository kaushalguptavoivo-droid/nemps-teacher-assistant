import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  verifyPassword,
  createToken,
  createSessionCookie,
  createLogoutCookie,
  verifyToken,
  getSessionCookieName,
  type SessionPayload,
} from "@/lib/auth";

// POST /api/auth — login, logout, or get current session
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    // ── Login ──────────────────────────────────────────────
    if (action === "login") {
      const { email, password } = body;
      if (!email || !password) {
        return NextResponse.json(
          { error: "Email and password are required" },
          { status: 400 }
        );
      }

      const user = await db.query.users.findFirst({
        where: eq(users.email, email),
      });

      if (!user || !user.isActive) {
        return NextResponse.json(
          { error: "Invalid credentials" },
          { status: 401 }
        );
      }

      const valid = await verifyPassword(password, user.passwordHash);
      if (!valid) {
        return NextResponse.json(
          { error: "Invalid credentials" },
          { status: 401 }
        );
      }

      const payload: SessionPayload = {
        userId: user.id,
        email: user.email,
        role: user.role as "admin" | "teacher",
        displayName: user.displayName,
      };

      const token = await createToken(payload);
      const response = NextResponse.json({
        user: {
          id: user.id,
          email: user.email,
          displayName: user.displayName,
          role: user.role,
          phone: user.phone,
        },
      });

      response.cookies.set(createSessionCookie(token));
      return response;
    }

    // ── Logout ─────────────────────────────────────────────
    if (action === "logout") {
      const response = NextResponse.json({ success: true });
      response.cookies.set(createLogoutCookie());
      return response;
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (error) {
    console.error("Auth error:", error);
    return NextResponse.json(
      { error: "Authentication failed" },
      { status: 500 }
    );
  }
}

// GET /api/auth — get current session
export async function GET(request: NextRequest) {
  try {
    const cookieName = getSessionCookieName();
    const token = request.cookies.get(cookieName)?.value;

    if (!token) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }

    const session = await verifyToken(token);
    if (!session) {
      return NextResponse.json(
        { error: "Invalid session" },
        { status: 401 }
      );
    }

    const user = await db.query.users.findFirst({
      where: eq(users.id, session.userId),
      columns: {
        id: true,
        email: true,
        displayName: true,
        role: true,
        phone: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    return NextResponse.json({ user });
  } catch (error) {
    console.error("Session error:", error);
    return NextResponse.json(
      { error: "Failed to get session" },
      { status: 500 }
    );
  }
}
