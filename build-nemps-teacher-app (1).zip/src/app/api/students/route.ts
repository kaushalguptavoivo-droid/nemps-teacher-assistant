import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { eq, ilike, and, or, inArray } from "drizzle-orm";

// GET /api/students — list students with optional filters
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const userId = request.headers.get("x-user-id");
    const { searchParams } = new URL(request.url);

    const className = searchParams.get("class");
    const search = searchParams.get("search");
    const studentId = searchParams.get("id");

    // If specific student ID requested
    if (studentId) {
      const student = await db.query.students.findFirst({
        where: eq(students.id, studentId),
      });
      if (!student) {
        return NextResponse.json({ error: "Student not found" }, { status: 404 });
      }
      return NextResponse.json({ student });
    }

    // Build conditions
    const conditions = [];

    if (className) {
      conditions.push(eq(students.className, className));
    } else if (userRole === "teacher") {
      // Teachers can only see their assigned classes
      const assignedClasses = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      const classNames = assignedClasses.map((c) => c.className);
      if (classNames.length === 0) {
        return NextResponse.json({ students: [] });
      }
      conditions.push(inArray(students.className, classNames));
    }

    if (search) {
      conditions.push(
        or(
          ilike(students.studentName, `%${search}%`),
          ilike(students.fatherName, `%${search}%`),
          ilike(students.rollNo, `%${search}%`)
        )!
      );
    }

    const result = await db.query.students.findMany({
      where: conditions.length > 0 ? and(...conditions) : undefined,
      orderBy: (students, { asc }) => [asc(students.rollNo)],
    });

    return NextResponse.json({ students: result });
  } catch (error) {
    console.error("Students list error:", error);
    return NextResponse.json({ error: "Failed to fetch students" }, { status: 500 });
  }
}

// POST /api/students — create a student (admin only)
export async function POST(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const {
      rollNo,
      studentName,
      fatherName,
      motherName,
      parentWhatsapp,
      alternatePhone,
      dob,
      address,
      className,
      photoUrl,
    } = body;

    if (!rollNo || !studentName || !className) {
      return NextResponse.json(
        { error: "Roll number, student name, and class are required" },
        { status: 400 }
      );
    }

    // Check for duplicate roll number in same class
    const existing = await db.query.students.findFirst({
      where: and(eq(students.rollNo, rollNo), eq(students.className, className)),
    });

    if (existing) {
      return NextResponse.json(
        { error: "Roll number already exists in this class" },
        { status: 409 }
      );
    }

    const [newStudent] = await db
      .insert(students)
      .values({
        rollNo,
        studentName,
        fatherName: fatherName || null,
        motherName: motherName || null,
        parentWhatsapp: parentWhatsapp || null,
        alternatePhone: alternatePhone || null,
        dob: dob || null,
        address: address || null,
        className,
        photoUrl: photoUrl || null,
      })
      .returning();

    return NextResponse.json({ student: newStudent }, { status: 201 });
  } catch (error) {
    console.error("Create student error:", error);
    return NextResponse.json({ error: "Failed to create student" }, { status: 500 });
  }
}

// PUT /api/students — update a student (admin only)
export async function PUT(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: "Student ID is required" }, { status: 400 });
    }

    const [updated] = await db
      .update(students)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(students.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Student not found" }, { status: 404 });
    }

    return NextResponse.json({ student: updated });
  } catch (error) {
    console.error("Update student error:", error);
    return NextResponse.json({ error: "Failed to update student" }, { status: 500 });
  }
}

// DELETE /api/students — delete a student (admin only)
export async function DELETE(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "Student ID is required" }, { status: 400 });
    }

    await db.delete(students).where(eq(students.id, id));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete student error:", error);
    return NextResponse.json({ error: "Failed to delete student" }, { status: 500 });
  }
}
