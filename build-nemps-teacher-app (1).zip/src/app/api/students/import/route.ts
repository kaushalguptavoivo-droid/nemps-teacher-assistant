import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import * as XLSX from "xlsx";
import { CLASSES } from "@/lib/constants";

// POST /api/students/import — import students from Excel (admin only)
export async function POST(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const formData = await request.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: "array" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(worksheet);

    const results = {
      imported: 0,
      skipped: 0,
      errors: [] as string[],
    };

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 2; // Excel row number (1-indexed + header)

      const rollNo = String(row["roll_no"] ?? "").trim();
      const studentName = String(row["student_name"] ?? "").trim();
      const fatherName = String(row["father_name"] ?? "").trim();
      const motherName = String(row["mother_name"] ?? "").trim();
      const parentWhatsapp = String(row["parent_whatsapp"] ?? "").trim();
      const alternatePhone = String(row["alternate_phone"] ?? "").trim();
      const dob = String(row["dob"] ?? "").trim();
      const address = String(row["address"] ?? "").trim();
      const className = String(row["class_name"] ?? "").trim();

      // Validate required fields
      if (!rollNo || !studentName || !className) {
        results.errors.push(`Row ${rowNum}: Missing required fields (roll_no, student_name, class_name)`);
        results.skipped++;
        continue;
      }

      // Validate class name
      if (!CLASSES.includes(className as typeof CLASSES[number])) {
        results.errors.push(`Row ${rowNum}: Invalid class "${className}"`);
        results.skipped++;
        continue;
      }

      // Check for duplicate roll number in same class
      const existing = await db.query.students.findFirst({
        where: and(eq(students.rollNo, rollNo), eq(students.className, className)),
      });

      if (existing) {
        results.errors.push(`Row ${rowNum}: Duplicate roll number "${rollNo}" in class "${className}"`);
        results.skipped++;
        continue;
      }

      // Insert student
      try {
        await db.insert(students).values({
          rollNo,
          studentName,
          fatherName: fatherName || null,
          motherName: motherName || null,
          parentWhatsapp: parentWhatsapp || null,
          alternatePhone: alternatePhone || null,
          dob: dob || null,
          address: address || null,
          className,
        });
        results.imported++;
      } catch (err) {
        results.errors.push(`Row ${rowNum}: Database error - ${String(err)}`);
        results.skipped++;
      }
    }

    return NextResponse.json(results);
  } catch (error) {
    console.error("Import error:", error);
    return NextResponse.json({ error: "Failed to import students" }, { status: 500 });
  }
}
