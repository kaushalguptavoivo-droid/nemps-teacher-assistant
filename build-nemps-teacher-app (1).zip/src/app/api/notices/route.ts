import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { notices } from "@/db/schema";
import { eq, and, or, inArray, isNull } from "drizzle-orm";

// GET /api/notices — list notices
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const userId = request.headers.get("x-user-id");
    const { searchParams } = new URL(request.url);

    const category = searchParams.get("category");

    let result;

    if (userRole === "admin") {
      // Admin sees all notices
      const conditions = [eq(notices.isActive, true)];
      if (category) conditions.push(eq(notices.category, category as typeof notices.category.enumValues[number]));

      result = await db.query.notices.findMany({
        where: and(...conditions),
        orderBy: (notices, { desc }) => [desc(notices.noticeDate)],
        limit: 50,
      });
    } else {
      // Teacher sees general notices + notices for their assigned classes
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      const classNames = assigned.map((a) => a.className);

      const conditions = [
        eq(notices.isActive, true),
        or(
          isNull(notices.className),
          inArray(notices.className, classNames)
        ),
      ];
      if (category) conditions.push(eq(notices.category, category as typeof notices.category.enumValues[number]));

      result = await db.query.notices.findMany({
        where: and(...conditions),
        orderBy: (notices, { desc }) => [desc(notices.noticeDate)],
        limit: 50,
      });
    }

    return NextResponse.json({ notices: result });
  } catch (error) {
    console.error("Notices GET error:", error);
    return NextResponse.json({ error: "Failed to fetch notices" }, { status: 500 });
  }
}

// POST /api/notices — create notice (admin only)
export async function POST(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const userId = request.headers.get("x-user-id");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { title, body: noticeBody, category, className, noticeDate } = body;

    if (!title || !noticeBody || !category || !noticeDate) {
      return NextResponse.json(
        { error: "Title, body, category, and date are required" },
        { status: 400 }
      );
    }

    const [newNotice] = await db
      .insert(notices)
      .values({
        title,
        body: noticeBody,
        category,
        className: className || null,
        noticeDate,
        createdBy: userId!,
      })
      .returning();

    return NextResponse.json({ notice: newNotice }, { status: 201 });
  } catch (error) {
    console.error("Notices POST error:", error);
    return NextResponse.json({ error: "Failed to create notice" }, { status: 500 });
  }
}

// PUT /api/notices — update/deactivate notice (admin only)
export async function PUT(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: "Notice ID is required" }, { status: 400 });
    }

    const [updated] = await db
      .update(notices)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(notices.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Notice not found" }, { status: 404 });
    }

    return NextResponse.json({ notice: updated });
  } catch (error) {
    console.error("Notices PUT error:", error);
    return NextResponse.json({ error: "Failed to update notice" }, { status: 500 });
  }
}
