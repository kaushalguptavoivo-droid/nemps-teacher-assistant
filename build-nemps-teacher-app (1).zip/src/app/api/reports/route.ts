import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { attendance, homework, homeworkStatus, fees, students } from "@/db/schema";
import { eq, and, count, gte, lte, inArray } from "drizzle-orm";
import { MONTHS } from "@/lib/constants";

// GET /api/reports — generate reports
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const { searchParams } = new URL(request.url);

    const type = searchParams.get("type"); // attendance, homework, fees
    const className = searchParams.get("class");
    const month = searchParams.get("month");
    const year = searchParams.get("year");

    if (!type || !className) {
      return NextResponse.json({ error: "Report type and class are required" }, { status: 400 });
    }

    // Teacher access check
    if (userRole === "teacher") {
      const userId = request.headers.get("x-user-id");
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      if (!assigned.some((a) => a.className === className)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }
    }

    // ── Attendance Report ──────────────────────────────────
    if (type === "attendance") {
      const yr = parseInt(year || new Date().getFullYear().toString());
      const mo = parseInt(month || (new Date().getMonth() + 1).toString());
      const startDate = `${yr}-${String(mo).padStart(2, "0")}-01`;
      const endDate = `${yr}-${String(mo).padStart(2, "0")}-31`;

      const classStudents = await db.query.students.findMany({
        where: eq(students.className, className),
        orderBy: (students, { asc }) => [asc(students.rollNo)],
      });

      const records = await db
        .select()
        .from(attendance)
        .where(
          and(
            eq(attendance.className, className),
            gte(attendance.attendanceDate, startDate),
            lte(attendance.attendanceDate, endDate)
          )
        );

      const report = classStudents.map((student) => {
        const studentRecords = records.filter((r) => r.studentId === student.id);
        const presentCount = studentRecords.filter((r) => r.status === "present").length;
        const totalDays = studentRecords.length;
        const percentage = totalDays > 0 ? Math.round((presentCount / totalDays) * 100) : 0;

        return {
          studentId: student.id,
          rollNo: student.rollNo,
          studentName: student.studentName,
          presentCount,
          absentCount: totalDays - presentCount,
          totalDays,
          percentage,
        };
      });

      return NextResponse.json({ report, month: MONTHS[mo - 1], year: yr, className });
    }

    // ── Homework Report ────────────────────────────────────
    if (type === "homework") {
      const classStudents = await db.query.students.findMany({
        where: eq(students.className, className),
        orderBy: (students, { asc }) => [asc(students.rollNo)],
      });

      // Get all homework for this class
      const classHomework = await db.query.homework.findMany({
        where: eq(homework.className, className),
      });

      const report = classStudents.map((student) => {
        return {
          studentId: student.id,
          rollNo: student.rollNo,
          studentName: student.studentName,
          totalHomework: classHomework.length,
        };
      });

      // Get detailed status counts
      const statusCounts = await db
        .select({
          studentId: homeworkStatus.studentId,
          status: homeworkStatus.status,
          count: count(),
        })
        .from(homeworkStatus)
        .innerJoin(homework, eq(homeworkStatus.homeworkId, homework.id))
        .where(eq(homework.className, className))
        .groupBy(homeworkStatus.studentId, homeworkStatus.status);

      const finalReport = report.map((r) => {
        const studentCounts = statusCounts.filter((sc) => sc.studentId === r.studentId);
        const completed = studentCounts.find((sc) => sc.status === "completed")?.count ?? 0;
        const pending = studentCounts.find((sc) => sc.status === "pending")?.count ?? 0;
        const notChecked = studentCounts.find((sc) => sc.status === "not_checked")?.count ?? 0;
        const total = completed + pending + notChecked;
        const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;

        return { ...r, completed, pending, notChecked, percentage };
      });

      return NextResponse.json({ report: finalReport, className });
    }

    // ── Fee Report ─────────────────────────────────────────
    if (type === "fees") {
      const yr = parseInt(year || new Date().getFullYear().toString());
      const mo = parseInt(month || (new Date().getMonth() + 1).toString());

      const feeRecords = await db
        .select({
          id: fees.id,
          studentId: fees.studentId,
          studentName: students.studentName,
          rollNo: students.rollNo,
          parentWhatsapp: students.parentWhatsapp,
          feeMonth: fees.feeMonth,
          feeYear: fees.feeYear,
          monthlyFeeAmount: fees.monthlyFeeAmount,
          examFeeAmount: fees.examFeeAmount,
          totalAmount: fees.totalAmount,
          dueDate: fees.dueDate,
          paidDate: fees.paidDate,
          status: fees.status,
          remarks: fees.remarks,
        })
        .from(fees)
        .innerJoin(students, eq(fees.studentId, students.id))
        .where(
          and(
            eq(students.className, className),
            eq(fees.feeMonth, mo),
            eq(fees.feeYear, yr)
          )
        )
        .orderBy(students.rollNo);

      const paidCount = feeRecords.filter((f) => f.status === "paid").length;
      const dueCount = feeRecords.filter((f) => f.status === "due").length;
      const overdueCount = feeRecords.filter((f) => f.status === "overdue").length;

      return NextResponse.json({
        report: feeRecords,
        summary: { paidCount, dueCount, overdueCount, total: feeRecords.length },
        month: MONTHS[mo - 1],
        year: yr,
        className,
      });
    }

    return NextResponse.json({ error: "Invalid report type" }, { status: 400 });
  } catch (error) {
    console.error("Reports error:", error);
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 });
  }
}
