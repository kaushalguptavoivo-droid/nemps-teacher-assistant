import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { messageTemplates } from "@/db/schema";
import { eq } from "drizzle-orm";

// GET /api/templates — list message templates
export async function GET() {
  try {
    const result = await db.query.messageTemplates.findMany({
      orderBy: (messageTemplates, { asc }) => [asc(messageTemplates.templateKey)],
    });
    return NextResponse.json({ templates: result });
  } catch (error) {
    console.error("Templates GET error:", error);
    return NextResponse.json({ error: "Failed to fetch templates" }, { status: 500 });
  }
}

// PUT /api/templates — update a template (admin only)
export async function PUT(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { id, title, bodyEn, bodyHi, isActive } = body;

    if (!id) {
      return NextResponse.json({ error: "Template ID is required" }, { status: 400 });
    }

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (title !== undefined) updates.title = title;
    if (bodyEn !== undefined) updates.bodyEn = bodyEn;
    if (bodyHi !== undefined) updates.bodyHi = bodyHi;
    if (isActive !== undefined) updates.isActive = isActive;

    const [updated] = await db
      .update(messageTemplates)
      .set(updates)
      .where(eq(messageTemplates.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Template not found" }, { status: 404 });
    }

    return NextResponse.json({ template: updated });
  } catch (error) {
    console.error("Templates PUT error:", error);
    return NextResponse.json({ error: "Failed to update template" }, { status: 500 });
  }
}
