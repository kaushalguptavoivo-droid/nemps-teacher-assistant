import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, classAssignments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";

// GET /api/teachers — list teachers (admin only)
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const teachers = await db.query.users.findMany({
      where: eq(users.role, "teacher"),
      columns: {
        id: true,
        email: true,
        displayName: true,
        phone: true,
        isActive: true,
        createdAt: true,
      },
    });

    // Get class assignments for each teacher
    const teachersWithClasses = await Promise.all(
      teachers.map(async (teacher) => {
        const assignments = await db.query.classAssignments.findMany({
          where: eq(classAssignments.userId, teacher.id),
          columns: { className: true },
        });
        return {
          ...teacher,
          classes: assignments.map((a) => a.className),
        };
      })
    );

    return NextResponse.json({ teachers: teachersWithClasses });
  } catch (error) {
    console.error("Teachers GET error:", error);
    return NextResponse.json({ error: "Failed to fetch teachers" }, { status: 500 });
  }
}

// POST /api/teachers — create a teacher (admin only)
export async function POST(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const adminId = request.headers.get("x-user-id");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { email, password, displayName, phone, classes } = body;

    if (!email || !password || !displayName) {
      return NextResponse.json(
        { error: "Email, password, and display name are required" },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existing = await db.query.users.findFirst({
      where: eq(users.email, email),
    });

    if (existing) {
      return NextResponse.json({ error: "Email already exists" }, { status: 409 });
    }

    const passwordHash = await hashPassword(password);

    const [newTeacher] = await db
      .insert(users)
      .values({
        email,
        passwordHash,
        displayName,
        phone: phone || null,
        role: "teacher",
      })
      .returning();

    // Assign classes
    if (classes && Array.isArray(classes) && classes.length > 0) {
      await db.insert(classAssignments).values(
        classes.map((className: string) => ({
          userId: newTeacher.id,
          className,
        }))
      );
    }

    return NextResponse.json(
      {
        teacher: {
          id: newTeacher.id,
          email: newTeacher.email,
          displayName: newTeacher.displayName,
          phone: newTeacher.phone,
          classes: classes || [],
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Teachers POST error:", error);
    return NextResponse.json({ error: "Failed to create teacher" }, { status: 500 });
  }
}

// PUT /api/teachers — update a teacher (admin only)
export async function PUT(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { id, displayName, phone, isActive, classes, password } = body;

    if (!id) {
      return NextResponse.json({ error: "Teacher ID is required" }, { status: 400 });
    }

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (displayName !== undefined) updates.displayName = displayName;
    if (phone !== undefined) updates.phone = phone;
    if (isActive !== undefined) updates.isActive = isActive;
    if (password) updates.passwordHash = await hashPassword(password);

    const [updated] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Teacher not found" }, { status: 404 });
    }

    // Update class assignments if provided
    if (classes && Array.isArray(classes)) {
      // Delete existing assignments
      await db.delete(classAssignments).where(eq(classAssignments.userId, id));

      // Insert new assignments
      if (classes.length > 0) {
        await db.insert(classAssignments).values(
          classes.map((className: string) => ({
            userId: id,
            className,
          }))
        );
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Teachers PUT error:", error);
    return NextResponse.json({ error: "Failed to update teacher" }, { status: 500 });
  }
}
