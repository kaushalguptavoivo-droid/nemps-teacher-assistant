import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, students, attendance, homework, homeworkStatus, fees, notices, classAssignments } from "@/db/schema";
import { eq, and, count, sql, inArray, or, isNull } from "drizzle-orm";

// GET /api/dashboard — aggregated dashboard stats
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get("x-user-id");
    const userRole = request.headers.get("x-user-role");

    if (!userId || !userRole) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const today = new Date().toISOString().split("T")[0];

    if (userRole === "admin") {
      // ── Admin Dashboard ───────────────────────────────────
      const [totalTeachers] = await db
        .select({ count: count() })
        .from(users)
        .where(eq(users.role, "teacher"));

      const [totalStudents] = await db
        .select({ count: count() })
        .from(students);

      // Class-wise student counts
      const classWiseCounts = await db
        .select({
          className: students.className,
          count: count(),
        })
        .from(students)
        .groupBy(students.className);

      // Fee due summary
      const [feeDueCount] = await db
        .select({ count: count() })
        .from(fees)
        .where(eq(fees.status, "due"));

      const [feeOverdueCount] = await db
        .select({ count: count() })
        .from(fees)
        .where(eq(fees.status, "overdue"));

      // Today's attendance summary
      const [presentToday] = await db
        .select({ count: count() })
        .from(attendance)
        .where(and(eq(attendance.attendanceDate, today), eq(attendance.status, "present")));

      const [absentToday] = await db
        .select({ count: count() })
        .from(attendance)
        .where(and(eq(attendance.attendanceDate, today), eq(attendance.status, "absent")));

      // Recent notices
      const recentNotices = await db.query.notices.findMany({
        where: eq(notices.isActive, true),
        orderBy: (notices, { desc }) => [desc(notices.createdAt)],
        limit: 5,
      });

      return NextResponse.json({
        role: "admin",
        totalTeachers: totalTeachers.count,
        totalStudents: totalStudents.count,
        classWiseCounts,
        feeDueCount: feeDueCount.count,
        feeOverdueCount: feeOverdueCount.count,
        presentToday: presentToday.count,
        absentToday: absentToday.count,
        recentNotices,
      });
    } else {
      // ── Teacher Dashboard ─────────────────────────────────
      // Get assigned classes
      const assignedClasses = await db
        .select({ className: classAssignments.className })
        .from(classAssignments)
        .where(eq(classAssignments.userId, userId));

      const classNames = assignedClasses.map((c) => c.className);

      if (classNames.length === 0) {
        return NextResponse.json({
          role: "teacher",
          assignedClasses: [],
          absentToday: 0,
          homeworkPending: 0,
          feeDueCount: 0,
          notices: [],
        });
      }

      // Today's absent count for assigned classes
      const absentToday = await db
        .select({ count: count() })
        .from(attendance)
        .where(
          and(
            eq(attendance.attendanceDate, today),
            eq(attendance.status, "absent"),
            inArray(attendance.className, classNames)
          )
        );

      // Homework pending count
      const hwPending = await db
        .select({ count: count() })
        .from(homeworkStatus)
        .innerJoin(homework, eq(homeworkStatus.homeworkId, homework.id))
        .where(
          and(
            eq(homeworkStatus.status, "pending"),
            inArray(homework.className, classNames)
          )
        );

      // Fee due count for assigned classes
      const feeDue = await db
        .select({ count: count() })
        .from(fees)
        .innerJoin(students, eq(fees.studentId, students.id))
        .where(
          and(
            eq(fees.status, "due"),
            inArray(students.className, classNames)
          )
        );

      // Notices for teacher (general + assigned classes)
      const teacherNotices = await db.query.notices.findMany({
        where: and(
          eq(notices.isActive, true),
          or(
            isNull(notices.className),
            inArray(notices.className, classNames)
          )
        ),
        orderBy: (notices, { desc }) => [desc(notices.createdAt)],
        limit: 5,
      });

      return NextResponse.json({
        role: "teacher",
        assignedClasses: classNames,
        absentToday: absentToday[0]?.count ?? 0,
        homeworkPending: hwPending[0]?.count ?? 0,
        feeDueCount: feeDue[0]?.count ?? 0,
        notices: teacherNotices,
      });
    }
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json(
      { error: "Failed to load dashboard" },
      { status: 500 }
    );
  }
}
