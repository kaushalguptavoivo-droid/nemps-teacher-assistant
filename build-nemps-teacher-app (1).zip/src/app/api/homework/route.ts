import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { homework, homeworkStatus, students } from "@/db/schema";
import { eq, and, inArray } from "drizzle-orm";

// GET /api/homework — list homework with filters
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const userId = request.headers.get("x-user-id");
    const { searchParams } = new URL(request.url);

    const className = searchParams.get("class");
    const subject = searchParams.get("subject");
    const homeworkId = searchParams.get("id");
    const includeStatus = searchParams.get("includeStatus") === "true";

    // If specific homework ID with status
    if (homeworkId && includeStatus) {
      const hw = await db.query.homework.findFirst({
        where: eq(homework.id, homeworkId),
      });
      if (!hw) {
        return NextResponse.json({ error: "Homework not found" }, { status: 404 });
      }

      // Get statuses for this homework
      const statuses = await db
        .select({
          id: homeworkStatus.id,
          studentId: homeworkStatus.studentId,
          studentName: students.studentName,
          rollNo: students.rollNo,
          parentWhatsapp: students.parentWhatsapp,
          status: homeworkStatus.status,
          checkedBy: homeworkStatus.checkedBy,
          checkedAt: homeworkStatus.checkedAt,
          remarks: homeworkStatus.remarks,
        })
        .from(homeworkStatus)
        .innerJoin(students, eq(homeworkStatus.studentId, students.id))
        .where(eq(homeworkStatus.homeworkId, homeworkId))
        .orderBy(students.rollNo);

      return NextResponse.json({ homework: hw, statuses });
    }

    // Build conditions
    const conditions = [];
    if (className) {
      conditions.push(eq(homework.className, className));
    } else if (userRole === "teacher") {
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      const classNames = assigned.map((a) => a.className);
      if (classNames.length === 0) {
        return NextResponse.json({ homework: [] });
      }
      conditions.push(inArray(homework.className, classNames));
    }

    if (subject) {
      conditions.push(eq(homework.subject, subject));
    }

    const result = await db.query.homework.findMany({
      where: conditions.length > 0 ? and(...conditions) : undefined,
      orderBy: (homework, { desc }) => [desc(homework.homeworkDate)],
      limit: 100,
    });

    return NextResponse.json({ homework: result });
  } catch (error) {
    console.error("Homework GET error:", error);
    return NextResponse.json({ error: "Failed to fetch homework" }, { status: 500 });
  }
}

// POST /api/homework — create homework
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get("x-user-id");
    const userRole = request.headers.get("x-user-role");
    const body = await request.json();

    const { className, subject, homeworkDate, title, description } = body;

    if (!className || !subject || !homeworkDate || !title) {
      return NextResponse.json(
        { error: "Class, subject, date, and title are required" },
        { status: 400 }
      );
    }

    // Teacher class access check
    if (userRole === "teacher") {
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      if (!assigned.some((a) => a.className === className)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }
    }

    const [newHomework] = await db
      .insert(homework)
      .values({
        className,
        subject,
        homeworkDate,
        title,
        description: description || null,
        createdBy: userId!,
      })
      .returning();

    // Create homework_status entries for all students in the class
    const classStudents = await db.query.students.findMany({
      where: eq(students.className, className),
    });

    if (classStudents.length > 0) {
      await db.insert(homeworkStatus).values(
        classStudents.map((s) => ({
          homeworkId: newHomework.id,
          studentId: s.id,
          status: "not_checked" as const,
        }))
      );
    }

    return NextResponse.json({ homework: newHomework }, { status: 201 });
  } catch (error) {
    console.error("Homework POST error:", error);
    return NextResponse.json({ error: "Failed to create homework" }, { status: 500 });
  }
}

// PUT /api/homework — update homework or homework status
export async function PUT(request: NextRequest) {
  try {
    const userId = request.headers.get("x-user-id");
    const body = await request.json();

    // Update homework status for a student
    if (body.type === "status") {
      const { homeworkId, studentId, status, remarks } = body;
      if (!homeworkId || !studentId || !status) {
        return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
      }

      const existing = await db.query.homeworkStatus.findFirst({
        where: and(
          eq(homeworkStatus.homeworkId, homeworkId),
          eq(homeworkStatus.studentId, studentId)
        ),
      });

      if (existing) {
        await db
          .update(homeworkStatus)
          .set({
            status,
            remarks: remarks || null,
            checkedBy: userId!,
            checkedAt: new Date(),
          })
          .where(eq(homeworkStatus.id, existing.id));
      } else {
        await db.insert(homeworkStatus).values({
          homeworkId,
          studentId,
          status,
          remarks: remarks || null,
          checkedBy: userId!,
          checkedAt: new Date(),
        });
      }

      return NextResponse.json({ success: true });
    }

    // Update homework itself
    const { id, ...updates } = body;
    if (!id) {
      return NextResponse.json({ error: "Homework ID is required" }, { status: 400 });
    }

    const [updated] = await db
      .update(homework)
      .set(updates)
      .where(eq(homework.id, id))
      .returning();

    return NextResponse.json({ homework: updated });
  } catch (error) {
    console.error("Homework PUT error:", error);
    return NextResponse.json({ error: "Failed to update homework" }, { status: 500 });
  }
}
