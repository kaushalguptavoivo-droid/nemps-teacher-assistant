import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { fees, students } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { FEE_DUE_DAY, FEE_OVERDUE_DAY, EXAM_FEE_AMOUNT, EXAM_FEE_MONTHS, MONTHS } from "@/lib/constants";

// GET /api/fees — list fee records
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const userId = request.headers.get("x-user-id");
    const { searchParams } = new URL(request.url);

    const className = searchParams.get("class");
    const feeMonth = searchParams.get("month");
    const feeYear = searchParams.get("year");
    const status = searchParams.get("status");

    if (!className) {
      return NextResponse.json({ error: "Class name is required" }, { status: 400 });
    }

    // Teacher class access check
    if (userRole === "teacher") {
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      if (!assigned.some((a) => a.className === className)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }
    }

    const conditions = [eq(students.className, className)];

    if (feeMonth) conditions.push(eq(fees.feeMonth, parseInt(feeMonth)));
    if (feeYear) conditions.push(eq(fees.feeYear, parseInt(feeYear)));
    if (status) conditions.push(eq(fees.status, status as "paid" | "due" | "overdue"));

    const result = await db
      .select({
        id: fees.id,
        studentId: fees.studentId,
        studentName: students.studentName,
        rollNo: students.rollNo,
        parentWhatsapp: students.parentWhatsapp,
        feeMonth: fees.feeMonth,
        feeYear: fees.feeYear,
        monthlyFeeAmount: fees.monthlyFeeAmount,
        examFeeAmount: fees.examFeeAmount,
        totalAmount: fees.totalAmount,
        dueDate: fees.dueDate,
        paidDate: fees.paidDate,
        status: fees.status,
        reminderCount: fees.reminderCount,
        remarks: fees.remarks,
      })
      .from(fees)
      .innerJoin(students, eq(fees.studentId, students.id))
      .where(and(...conditions))
      .orderBy(students.rollNo);

    return NextResponse.json({ fees: result });
  } catch (error) {
    console.error("Fees GET error:", error);
    return NextResponse.json({ error: "Failed to fetch fees" }, { status: 500 });
  }
}

// POST /api/fees — generate fee records for a class/month (admin only)
export async function POST(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { className, feeMonth, feeYear, monthlyFeeAmount } = body;

    if (!className || !feeMonth || !feeYear) {
      return NextResponse.json({ error: "Class, month, and year are required" }, { status: 400 });
    }

    const month = parseInt(feeMonth);
    const year = parseInt(feeYear);
    const monthlyAmt = monthlyFeeAmount ? parseFloat(monthlyFeeAmount) : null;

    // Check if exam fee applies
    const isExamMonth = EXAM_FEE_MONTHS.includes(month);
    const examFee = isExamMonth ? EXAM_FEE_AMOUNT.toString() : null;
    const totalAmt = monthlyAmt
      ? isExamMonth
        ? (monthlyAmt + EXAM_FEE_AMOUNT).toString()
        : monthlyAmt.toString()
      : null;

    // Due date = 7th of the month
    const dueDate = `${year}-${String(month).padStart(2, "0")}-${String(FEE_DUE_DAY).padStart(2, "0")}`;

    // Get all students in the class
    const classStudents = await db.query.students.findMany({
      where: eq(students.className, className),
    });

    let created = 0;
    let skipped = 0;

    for (const student of classStudents) {
      // Check if fee record already exists
      const existing = await db.query.fees.findFirst({
        where: and(
          eq(fees.studentId, student.id),
          eq(fees.feeMonth, month),
          eq(fees.feeYear, year)
        ),
      });

      if (existing) {
        skipped++;
        continue;
      }

      await db.insert(fees).values({
        studentId: student.id,
        feeMonth: month,
        feeYear: year,
        monthlyFeeAmount: monthlyAmt ? monthlyAmt.toString() : null,
        examFeeAmount: examFee,
        totalAmount: totalAmt,
        dueDate,
        status: "due",
      });
      created++;
    }

    return NextResponse.json({ created, skipped });
  } catch (error) {
    console.error("Fees POST error:", error);
    return NextResponse.json({ error: "Failed to generate fees" }, { status: 500 });
  }
}

// PUT /api/fees — update fee record (admin only)
export async function PUT(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    if (userRole !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await request.json();
    const { id, status, paidDate, remarks } = body;

    if (!id) {
      return NextResponse.json({ error: "Fee record ID is required" }, { status: 400 });
    }

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (status) updates.status = status;
    if (paidDate) updates.paidDate = paidDate;
    if (status === "paid" && !paidDate) updates.paidDate = new Date().toISOString().split("T")[0];
    if (remarks !== undefined) updates.remarks = remarks;

    const [updated] = await db
      .update(fees)
      .set(updates)
      .where(eq(fees.id, id))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Fee record not found" }, { status: 404 });
    }

    return NextResponse.json({ fee: updated });
  } catch (error) {
    console.error("Fees PUT error:", error);
    return NextResponse.json({ error: "Failed to update fee" }, { status: 500 });
  }
}
