import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { attendance, students } from "@/db/schema";
import { eq, and, sql, gte, lte, count } from "drizzle-orm";

// GET /api/attendance — get attendance records
export async function GET(request: NextRequest) {
  try {
    const userRole = request.headers.get("x-user-role");
    const userId = request.headers.get("x-user-id");
    const { searchParams } = new URL(request.url);

    const className = searchParams.get("class");
    const date = searchParams.get("date");
    const month = searchParams.get("month");
    const year = searchParams.get("year");
    const reportType = searchParams.get("report");

    if (!className) {
      return NextResponse.json({ error: "Class name is required" }, { status: 400 });
    }

    // Teacher class access check
    if (userRole === "teacher") {
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      if (!assigned.some((a) => a.className === className)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }
    }

    // ── Monthly report ────────────────────────────────────
    if (reportType === "monthly" && month && year) {
      const startDate = `${year}-${month.padStart(2, "0")}-01`;
      const endDate = `${year}-${month.padStart(2, "0")}-31`;

      // Get students in this class
      const classStudents = await db.query.students.findMany({
        where: eq(students.className, className),
        orderBy: (students, { asc }) => [asc(students.rollNo)],
      });

      // Get attendance records for the month
      const records = await db
        .select()
        .from(attendance)
        .where(
          and(
            eq(attendance.className, className),
            gte(attendance.attendanceDate, startDate),
            lte(attendance.attendanceDate, endDate)
          )
        );

      // Calculate per-student stats
      const stats = classStudents.map((student) => {
        const studentRecords = records.filter(
          (r) => r.studentId === student.id
        );
        const presentCount = studentRecords.filter(
          (r) => r.status === "present"
        ).length;
        const totalDays = studentRecords.length;
        const percentage = totalDays > 0 ? Math.round((presentCount / totalDays) * 100) : 0;

        return {
          studentId: student.id,
          studentName: student.studentName,
          rollNo: student.rollNo,
          presentCount,
          absentCount: totalDays - presentCount,
          totalDays,
          percentage,
        };
      });

      return NextResponse.json({ stats });
    }

    // ── Daily attendance ──────────────────────────────────
    if (!date) {
      return NextResponse.json({ error: "Date is required for daily attendance" }, { status: 400 });
    }

    // Get students in the class
    const classStudents = await db.query.students.findMany({
      where: eq(students.className, className),
      orderBy: (students, { asc }) => [asc(students.rollNo)],
    });

    // Get existing attendance records
    const records = await db
      .select()
      .from(attendance)
      .where(
        and(
          eq(attendance.className, className),
          eq(attendance.attendanceDate, date)
        )
      );

    // Merge student data with attendance
    const result = classStudents.map((student) => {
      const record = records.find((r) => r.studentId === student.id);
      return {
        studentId: student.id,
        studentName: student.studentName,
        rollNo: student.rollNo,
        parentWhatsapp: student.parentWhatsapp,
        status: record?.status ?? null,
        attendanceId: record?.id ?? null,
        remarks: record?.remarks ?? null,
      };
    });

    return NextResponse.json({ attendance: result, date, className });
  } catch (error) {
    console.error("Attendance GET error:", error);
    return NextResponse.json({ error: "Failed to fetch attendance" }, { status: 500 });
  }
}

// POST /api/attendance — save/update attendance
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get("x-user-id");
    const userRole = request.headers.get("x-user-role");
    const body = await request.json();

    const { className, date, records } = body;

    if (!className || !date || !records || !Array.isArray(records)) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    // Teacher class access check
    if (userRole === "teacher") {
      const assigned = await db.query.classAssignments.findMany({
        where: (ca, { eq }) => eq(ca.userId, userId!),
      });
      if (!assigned.some((a) => a.className === className)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
      }
    }

    let upserted = 0;

    for (const record of records) {
      const { studentId, status, remarks } = record;
      if (!studentId || !status) continue;

      // Check if attendance already exists
      const existing = await db.query.attendance.findFirst({
        where: and(
          eq(attendance.studentId, studentId),
          eq(attendance.attendanceDate, date)
        ),
      });

      if (existing) {
        // Update existing record
        await db
          .update(attendance)
          .set({ status, remarks: remarks || null, markedBy: userId! })
          .where(eq(attendance.id, existing.id));
      } else {
        // Insert new record
        await db.insert(attendance).values({
          studentId,
          className,
          attendanceDate: date,
          status,
          markedBy: userId!,
          remarks: remarks || null,
        });
      }
      upserted++;
    }

    return NextResponse.json({ success: true, upserted });
  } catch (error) {
    console.error("Attendance POST error:", error);
    return NextResponse.json({ error: "Failed to save attendance" }, { status: 500 });
  }
}
