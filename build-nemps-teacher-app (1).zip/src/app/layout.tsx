import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "NEMPS Teacher Assistant",
  description: "New Era Modern Public School, Vrindavan — Teacher productivity app",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#4f46e5",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="bg-surface-50 text-slate-900 antialiased dark:bg-surface-950 dark:text-slate-100">
        {children}
      </body>
    </html>
  );
}
