"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../layout";
import { CLASSES } from "@/lib/constants";

interface Student {
  id: string;
  rollNo: string;
  studentName: string;
  fatherName: string | null;
  motherName: string | null;
  parentWhatsapp: string | null;
  alternatePhone: string | null;
  dob: string | null;
  address: string | null;
  className: string;
  photoUrl: string | null;
}

export default function StudentsPage() {
  const { user, assignedClasses } = useAuth();
  const isAdmin = user?.role === "admin";
  const classes = isAdmin ? (CLASSES as readonly string[]) : assignedClasses;

  const [selectedClass, setSelectedClass] = useState(classes[0] || "");
  const [search, setSearch] = useState("");
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [message, setMessage] = useState("");

  // Add form fields
  const [form, setForm] = useState({
    rollNo: "",
    studentName: "",
    fatherName: "",
    motherName: "",
    parentWhatsapp: "",
    alternatePhone: "",
    dob: "",
    address: "",
    className: "",
  });

  useEffect(() => {
    if (selectedClass) fetchStudents();
  }, [selectedClass, search]);

  const fetchStudents = async () => {
    setLoading(true);
    try {
      let url = `/api/students?class=${encodeURIComponent(selectedClass)}`;
      if (search) url += `&search=${encodeURIComponent(search)}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setStudents(data.students || []);
      }
    } catch (err) {
      console.error("Fetch students error:", err);
    } finally {
      setLoading(false);
    }
  };

  const addStudent = async () => {
    if (!form.rollNo || !form.studentName || !form.className) {
      setMessage("❌ Roll number, name, and class are required");
      return;
    }
    try {
      const res = await fetch("/api/students", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setMessage("✅ Student added");
        setShowAddForm(false);
        setForm({ rollNo: "", studentName: "", fatherName: "", motherName: "", parentWhatsapp: "", alternatePhone: "", dob: "", address: "", className: "" });
        fetchStudents();
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Network error");
    }
  };

  const sendWhatsApp = (phone: string | null, studentName: string) => {
    if (!phone) return;
    const msg = encodeURIComponent(`Hello, this is regarding ${studentName} from New Era Modern Public School, Vrindavan.`);
    const cleanPhone = phone.replace(/\D/g, "");
    const phoneWithCode = cleanPhone.startsWith("91") ? cleanPhone : `91${cleanPhone}`;
    window.open(`https://wa.me/${phoneWithCode}?text=${msg}`, "_blank");
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Students</h1>
        {isAdmin && (
          <button
            onClick={() => { setShowAddForm(true); setSelectedStudent(null); }}
            className="px-4 py-2 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            + Add Student
          </button>
        )}
      </div>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {/* Add Student Form */}
      {showAddForm && (
        <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <h3 className="font-semibold text-slate-900 dark:text-white">Add New Student</h3>
          <div className="grid grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Roll No *"
              value={form.rollNo}
              onChange={(e) => setForm({ ...form, rollNo: e.target.value })}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
            <select
              value={form.className || selectedClass}
              onChange={(e) => setForm({ ...form, className: e.target.value })}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {CLASSES.map((cls) => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>
          </div>
          <input
            type="text"
            placeholder="Student Name *"
            value={form.studentName}
            onChange={(e) => setForm({ ...form, studentName: e.target.value })}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
          <div className="grid grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Father's Name"
              value={form.fatherName}
              onChange={(e) => setForm({ ...form, fatherName: e.target.value })}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
            <input
              type="text"
              placeholder="Mother's Name"
              value={form.motherName}
              onChange={(e) => setForm({ ...form, motherName: e.target.value })}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <input
              type="text"
              placeholder="Parent WhatsApp"
              value={form.parentWhatsapp}
              onChange={(e) => setForm({ ...form, parentWhatsapp: e.target.value })}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
            <input
              type="text"
              placeholder="Alternate Phone"
              value={form.alternatePhone}
              onChange={(e) => setForm({ ...form, alternatePhone: e.target.value })}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
          </div>
          <input
            type="date"
            value={form.dob}
            onChange={(e) => setForm({ ...form, dob: e.target.value })}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
          <textarea
            placeholder="Address"
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            rows={2}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white resize-none"
          />
          <div className="flex gap-2">
            <button onClick={addStudent} className="flex-1 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">Add Student</button>
            <button onClick={() => setShowAddForm(false)} className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-400">Cancel</button>
          </div>
        </div>
      )}

      {/* Student Profile View */}
      {selectedStudent ? (
        <div>
          <button
            onClick={() => setSelectedStudent(null)}
            className="text-sm text-primary-600 dark:text-primary-400 font-medium mb-3 hover:underline"
          >
            ← Back to list
          </button>
          <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="bg-primary-600 dark:bg-primary-800 p-6 text-center">
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-2">
                <span className="text-2xl font-bold text-white">{selectedStudent.studentName.charAt(0)}</span>
              </div>
              <h2 className="text-lg font-bold text-white">{selectedStudent.studentName}</h2>
              <p className="text-primary-200 text-sm">Class {selectedStudent.className} • Roll {selectedStudent.rollNo}</p>
            </div>
            <div className="p-4 space-y-3">
              {selectedStudent.fatherName && (
                <InfoRow label="Father" value={selectedStudent.fatherName} />
              )}
              {selectedStudent.motherName && (
                <InfoRow label="Mother" value={selectedStudent.motherName} />
              )}
              {selectedStudent.parentWhatsapp && (
                <div className="flex items-center justify-between">
                  <InfoRow label="WhatsApp" value={selectedStudent.parentWhatsapp} />
                  <button
                    onClick={() => sendWhatsApp(selectedStudent.parentWhatsapp, selectedStudent.studentName)}
                    className="px-3 py-1.5 rounded-lg bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-xs font-medium"
                  >
                    WhatsApp
                  </button>
                </div>
              )}
              {selectedStudent.alternatePhone && (
                <InfoRow label="Alt Phone" value={selectedStudent.alternatePhone} />
              )}
              {selectedStudent.dob && (
                <InfoRow label="DOB" value={selectedStudent.dob} />
              )}
              {selectedStudent.address && (
                <InfoRow label="Address" value={selectedStudent.address} />
              )}
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* Filters */}
          <div className="flex gap-2">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {classes.map((cls) => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>
            <input
              type="text"
              placeholder="Search students..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
          </div>

          {/* Student List */}
          {loading ? (
            <div className="space-y-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="skeleton h-14 rounded-xl"></div>
              ))}
            </div>
          ) : students.length === 0 ? (
            <div className="text-center py-12 text-slate-500 dark:text-slate-400">
              <p className="text-4xl mb-2">👨‍🎓</p>
              <p className="font-medium">No students found</p>
            </div>
          ) : (
            <div className="space-y-2">
              {students.map((student) => (
                <button
                  key={student.id}
                  onClick={() => setSelectedStudent(student)}
                  className="w-full bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3 flex items-center gap-3 text-left card-hover"
                >
                  <div className="w-10 h-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                    <span className="text-sm font-semibold text-primary-600 dark:text-primary-400">
                      {student.studentName.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{student.studentName}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Roll: {student.rollNo} • {student.className}</p>
                  </div>
                  {student.parentWhatsapp && (
                    <button
                      onClick={(e) => { e.stopPropagation(); sendWhatsApp(student.parentWhatsapp, student.studentName); }}
                      className="p-2 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30"
                    >
                      <svg className="w-4 h-4 text-green-600" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                    </button>
                  )}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-1">
      <span className="text-xs text-slate-500 dark:text-slate-400">{label}</span>
      <span className="text-sm text-slate-900 dark:text-white font-medium">{value}</span>
    </div>
  );
}
