"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../layout";
import { NOTICE_CATEGORIES, CLASSES } from "@/lib/constants";

interface Notice {
  id: string;
  title: string;
  body: string;
  category: string;
  className: string | null;
  noticeDate: string;
  createdBy: string;
  isActive: boolean;
}

const categoryColors: Record<string, string> = {
  Holiday: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  Exam: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  PTM: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  Homework: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  Circular: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
  General: "bg-slate-100 text-slate-700 dark:bg-slate-700/30 dark:text-slate-400",
};

const categoryIcons: Record<string, string> = {
  Holiday: "🏖️",
  Exam: "📝",
  PTM: "🤝",
  Homework: "📚",
  Circular: "📢",
  General: "ℹ️",
};

export default function NoticesPage() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";

  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [message, setMessage] = useState("");

  // Create form
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [category, setCategory] = useState<string>(NOTICE_CATEGORIES[0]);
  const [className, setClassName] = useState("");
  const [noticeDate, setNoticeDate] = useState(new Date().toISOString().split("T")[0]);

  useEffect(() => {
    fetchNotices();
  }, [categoryFilter]);

  const fetchNotices = async () => {
    setLoading(true);
    try {
      let url = "/api/notices";
      if (categoryFilter) url += `?category=${categoryFilter}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setNotices(data.notices || []);
      }
    } catch (err) {
      console.error("Fetch notices error:", err);
    } finally {
      setLoading(false);
    }
  };

  const createNotice = async () => {
    if (!title || !body || !category || !noticeDate) {
      setMessage("❌ All fields are required");
      return;
    }
    try {
      const res = await fetch("/api/notices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          body,
          category,
          className: className || null,
          noticeDate,
        }),
      });
      if (res.ok) {
        setMessage("✅ Notice created");
        setShowCreate(false);
        setTitle("");
        setBody("");
        setCategory(NOTICE_CATEGORIES[0]);
        setClassName("");
        fetchNotices();
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Network error");
    }
  };

  const deactivateNotice = async (id: string) => {
    try {
      await fetch("/api/notices", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, isActive: false }),
      });
      setNotices((prev) => prev.filter((n) => n.id !== id));
    } catch (err) {
      console.error("Deactivate notice error:", err);
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Notices</h1>
        {isAdmin && (
          <button
            onClick={() => setShowCreate(true)}
            className="px-4 py-2 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            + Create Notice
          </button>
        )}
      </div>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {showCreate && (
        <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <h3 className="font-semibold text-slate-900 dark:text-white">Create Notice</h3>
          <input
            type="text"
            placeholder="Title *"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
          <textarea
            placeholder="Notice body *"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={3}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white resize-none"
          />
          <div className="grid grid-cols-2 gap-3">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {NOTICE_CATEGORIES.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
            <input
              type="date"
              value={noticeDate}
              onChange={(e) => setNoticeDate(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            />
          </div>
          <select
            value={className}
            onChange={(e) => setClassName(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          >
            <option value="">General (All Classes)</option>
            {CLASSES.map((cls) => (
              <option key={cls} value={cls}>{cls}</option>
            ))}
          </select>
          <div className="flex gap-2">
            <button onClick={createNotice} className="flex-1 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">Create</button>
            <button onClick={() => setShowCreate(false)} className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-400">Cancel</button>
          </div>
        </div>
      )}

      {/* Category filters */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setCategoryFilter("")}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            !categoryFilter
              ? "bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400"
              : "bg-slate-100 dark:bg-surface-800 text-slate-500 dark:text-slate-400"
          }`}
        >
          All
        </button>
        {NOTICE_CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              categoryFilter === cat
                ? categoryColors[cat]
                : "bg-slate-100 dark:bg-surface-800 text-slate-500 dark:text-slate-400"
            }`}
          >
            {categoryIcons[cat]} {cat}
          </button>
        ))}
      </div>

      {/* Notices */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton h-24 rounded-xl"></div>
          ))}
        </div>
      ) : notices.length === 0 ? (
        <div className="text-center py-12 text-slate-500 dark:text-slate-400">
          <p className="text-4xl mb-2">📢</p>
          <p className="font-medium">No notices</p>
        </div>
      ) : (
        <div className="space-y-3">
          {notices.map((notice) => (
            <div
              key={notice.id}
              className="bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 card-hover"
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{categoryIcons[notice.category] || "ℹ️"}</span>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{notice.title}</h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 whitespace-pre-wrap">{notice.body}</p>
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-medium ${categoryColors[notice.category] || categoryColors.General}`}>
                      {notice.category}
                    </span>
                    {notice.className && (
                      <span className="inline-flex px-2 py-0.5 rounded-md text-[10px] font-medium bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-400">
                        {notice.className}
                      </span>
                    )}
                    <span className="text-xs text-slate-400">{notice.noticeDate}</span>
                  </div>
                </div>
                {isAdmin && (
                  <button
                    onClick={() => deactivateNotice(notice.id)}
                    className="text-xs text-red-500 hover:text-red-600 font-medium shrink-0"
                  >
                    Remove
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
