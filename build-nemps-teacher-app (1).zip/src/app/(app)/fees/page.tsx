"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../layout";
import { CLASSES, MONTHS, FEE_DUE_DAY, EXAM_FEE_AMOUNT } from "@/lib/constants";

interface FeeRecord {
  id: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  parentWhatsapp: string | null;
  feeMonth: number;
  feeYear: number;
  monthlyFeeAmount: string | null;
  examFeeAmount: string | null;
  totalAmount: string | null;
  dueDate: string;
  paidDate: string | null;
  status: "paid" | "due" | "overdue";
  reminderCount: number;
  remarks: string | null;
}

export default function FeesPage() {
  const { user, assignedClasses } = useAuth();
  const isAdmin = user?.role === "admin";
  const classes = isAdmin ? (CLASSES as readonly string[]) : assignedClasses;

  const now = new Date();
  const [selectedClass, setSelectedClass] = useState(classes[0] || "");
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [statusFilter, setStatusFilter] = useState("");
  const [fees, setFees] = useState<FeeRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [showGenerate, setShowGenerate] = useState(false);
  const [monthlyFeeAmount, setMonthlyFeeAmount] = useState("");

  useEffect(() => {
    if (selectedClass) fetchFees();
  }, [selectedClass, selectedMonth, selectedYear, statusFilter]);

  const fetchFees = async () => {
    setLoading(true);
    try {
      let url = `/api/fees?class=${encodeURIComponent(selectedClass)}&month=${selectedMonth}&year=${selectedYear}`;
      if (statusFilter) url += `&status=${statusFilter}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setFees(data.fees || []);
      }
    } catch (err) {
      console.error("Fetch fees error:", err);
    } finally {
      setLoading(false);
    }
  };

  const generateFees = async () => {
    if (!monthlyFeeAmount) {
      setMessage("❌ Enter monthly fee amount");
      return;
    }
    try {
      const res = await fetch("/api/fees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          className: selectedClass,
          feeMonth: selectedMonth,
          feeYear: selectedYear,
          monthlyFeeAmount,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setMessage(`✅ Created ${data.created} fee records (${data.skipped} skipped)`);
        setShowGenerate(false);
        fetchFees();
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Network error");
    }
  };

  const updateFeeStatus = async (feeId: string, status: "paid" | "due" | "overdue") => {
    try {
      const res = await fetch("/api/fees", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: feeId, status }),
      });
      if (res.ok) {
        setFees((prev) =>
          prev.map((f) => (f.id === feeId ? { ...f, status } : f))
        );
      }
    } catch (err) {
      console.error("Update fee error:", err);
    }
  };

  const sendFeeReminder = (phone: string | null, studentName: string, amount: string | null, month: number) => {
    if (!phone) return;
    const monthName = MONTHS[month - 1];
    const msg = encodeURIComponent(
      `Dear Parent, fee of ₹${amount || "—"} for ${monthName} is due for ${studentName}. Please pay before due date. - New Era Modern Public School, Vrindavan`
    );
    const cleanPhone = phone.replace(/\D/g, "");
    const phoneWithCode = cleanPhone.startsWith("91") ? cleanPhone : `91${cleanPhone}`;
    window.open(`https://wa.me/${phoneWithCode}?text=${msg}`, "_blank");
  };

  const paidCount = fees.filter((f) => f.status === "paid").length;
  const dueCount = fees.filter((f) => f.status === "due").length;
  const overdueCount = fees.filter((f) => f.status === "overdue").length;

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Fees</h1>
        {isAdmin && (
          <button
            onClick={() => setShowGenerate(true)}
            className="px-4 py-2 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 transition-colors"
          >
            Generate Fees
          </button>
        )}
      </div>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {showGenerate && (
        <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <h3 className="font-semibold text-slate-900 dark:text-white">Generate Fee Records</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            This will create fee records for all students in <strong>{selectedClass}</strong> for <strong>{MONTHS[selectedMonth - 1]} {selectedYear}</strong>
          </p>
          <input
            type="number"
            placeholder="Monthly fee amount (₹)"
            value={monthlyFeeAmount}
            onChange={(e) => setMonthlyFeeAmount(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
          <p className="text-xs text-slate-400">Exam fee of ₹{EXAM_FEE_AMOUNT} will be added automatically for exam months (March, September)</p>
          <div className="flex gap-2">
            <button onClick={generateFees} className="flex-1 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700">Generate</button>
            <button onClick={() => setShowGenerate(false)} className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-400">Cancel</button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <select
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {classes.map((cls) => (
            <option key={cls} value={cls}>{cls}</option>
          ))}
        </select>
        <select
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {MONTHS.map((m, i) => (
            <option key={i} value={i + 1}>{m}</option>
          ))}
        </select>
        <select
          value={selectedYear}
          onChange={(e) => setSelectedYear(parseInt(e.target.value))}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {[2024, 2025, 2026].map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          <option value="">All Status</option>
          <option value="paid">Paid</option>
          <option value="due">Due</option>
          <option value="overdue">Overdue</option>
        </select>
      </div>

      {/* Summary */}
      {fees.length > 0 && (
        <div className="flex gap-3">
          <div className="flex-1 bg-green-50 dark:bg-green-950/30 rounded-xl p-3 text-center">
            <p className="text-lg font-bold text-green-700 dark:text-green-400">{paidCount}</p>
            <p className="text-xs text-green-600 dark:text-green-500">Paid</p>
          </div>
          <div className="flex-1 bg-amber-50 dark:bg-amber-950/30 rounded-xl p-3 text-center">
            <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{dueCount}</p>
            <p className="text-xs text-amber-600 dark:text-amber-500">Due</p>
          </div>
          <div className="flex-1 bg-red-50 dark:bg-red-950/30 rounded-xl p-3 text-center">
            <p className="text-lg font-bold text-red-700 dark:text-red-400">{overdueCount}</p>
            <p className="text-xs text-red-600 dark:text-red-500">Overdue</p>
          </div>
        </div>
      )}

      {/* Fee List */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="skeleton h-16 rounded-xl"></div>
          ))}
        </div>
      ) : fees.length === 0 ? (
        <div className="text-center py-12 text-slate-500 dark:text-slate-400">
          <p className="text-4xl mb-2">💰</p>
          <p className="font-medium">No fee records</p>
          <p className="text-sm">Generate fees for this month or select a different period</p>
        </div>
      ) : (
        <div className="space-y-2">
          {fees.map((fee) => (
            <div
              key={fee.id}
              className={`bg-white dark:bg-surface-900 rounded-xl border p-3 flex items-center gap-3 ${
                fee.status === "paid"
                  ? "border-green-200 dark:border-green-800"
                  : fee.status === "overdue"
                  ? "border-red-200 dark:border-red-800"
                  : "border-amber-200 dark:border-amber-800"
              }`}
            >
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{fee.studentName}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Roll: {fee.rollNo}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs text-slate-400">₹{fee.totalAmount || "—"}</span>
                  <span className="text-xs text-slate-400">Due: {fee.dueDate}</span>
                </div>
              </div>

              <span className={`inline-flex px-2.5 py-1 rounded-lg text-xs font-semibold ${
                fee.status === "paid"
                  ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                  : fee.status === "overdue"
                  ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                  : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
              }`}>
                {fee.status}
              </span>

              {isAdmin && fee.status !== "paid" && (
                <button
                  onClick={() => updateFeeStatus(fee.id, "paid")}
                  className="px-3 py-1.5 rounded-lg bg-green-500 text-white text-xs font-medium hover:bg-green-600 transition-colors"
                >
                  Mark Paid
                </button>
              )}

              {fee.status !== "paid" && fee.parentWhatsapp && (
                <button
                  onClick={() => sendFeeReminder(fee.parentWhatsapp, fee.studentName, fee.totalAmount, fee.feeMonth)}
                  className="p-1.5 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30"
                >
                  <svg className="w-4 h-4 text-green-600" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
