"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../layout";

interface Template {
  id: string;
  templateKey: string;
  title: string;
  bodyEn: string;
  bodyHi: string;
  isActive: boolean;
}

export default function TemplatesPage() {
  const { user } = useAuth();
  const isAdmin = user?.role === "admin";
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({ title: "", bodyEn: "", bodyHi: "" });
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/templates");
      if (res.ok) {
        const data = await res.json();
        setTemplates(data.templates || []);
      }
    } catch (err) {
      console.error("Fetch templates error:", err);
    } finally {
      setLoading(false);
    }
  };

  const startEdit = (template: Template) => {
    setEditingId(template.id);
    setEditForm({ title: template.title, bodyEn: template.bodyEn, bodyHi: template.bodyHi });
  };

  const saveTemplate = async () => {
    if (!editingId) return;
    try {
      const res = await fetch("/api/templates", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: editingId, ...editForm }),
      });
      if (res.ok) {
        setMessage("✅ Template updated");
        setEditingId(null);
        fetchTemplates();
      } else {
        setMessage("❌ Failed to update");
      }
    } catch {
      setMessage("❌ Network error");
    }
  };

  const templateIcons: Record<string, string> = {
    absent_student: "📋",
    homework_pending: "📚",
    fee_due: "💰",
    general_notice: "📢",
    ptm_notice: "🤝",
  };

  const placeholders = [
    "{student_name}",
    "{class_name}",
    "{date}",
    "{fee_month}",
    "{amount}",
    "{school_name}",
  ];

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold text-slate-900 dark:text-white">Message Templates</h1>

      <p className="text-sm text-slate-500 dark:text-slate-400">
        These templates are used to generate WhatsApp messages. Available placeholders: {placeholders.join(", ")}
      </p>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="skeleton h-32 rounded-xl"></div>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {templates.map((template) => (
            <div
              key={template.id}
              className="bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4"
            >
              {editingId === template.id ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    value={editForm.title}
                    onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
                  />
                  <div>
                    <label className="text-xs text-slate-500 dark:text-slate-400 mb-1 block">English</label>
                    <textarea
                      value={editForm.bodyEn}
                      onChange={(e) => setEditForm({ ...editForm, bodyEn: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white resize-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-500 dark:text-slate-400 mb-1 block">Hindi</label>
                    <textarea
                      value={editForm.bodyHi}
                      onChange={(e) => setEditForm({ ...editForm, bodyHi: e.target.value })}
                      rows={3}
                      className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white resize-none"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={saveTemplate}
                      className="flex-1 py-2 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-400"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xl">{templateIcons[template.templateKey] || "💬"}</span>
                    <h3 className="text-sm font-semibold text-slate-900 dark:text-white">{template.title}</h3>
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-surface-800 text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                      {template.templateKey}
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div className="p-2 rounded-lg bg-slate-50 dark:bg-surface-800">
                      <p className="text-xs text-slate-400 mb-0.5">English</p>
                      <p className="text-sm text-slate-700 dark:text-slate-300">{template.bodyEn}</p>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-50 dark:bg-surface-800">
                      <p className="text-xs text-slate-400 mb-0.5">Hindi</p>
                      <p className="text-sm text-slate-700 dark:text-slate-300">{template.bodyHi}</p>
                    </div>
                  </div>
                  {isAdmin && (
                    <button
                      onClick={() => startEdit(template)}
                      className="mt-2 text-xs text-primary-600 dark:text-primary-400 font-medium hover:underline"
                    >
                      Edit Template
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
