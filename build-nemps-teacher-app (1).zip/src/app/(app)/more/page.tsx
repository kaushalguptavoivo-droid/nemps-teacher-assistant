"use client";

import { useRouter } from "next/navigation";
import { useAuth } from "../layout";

export default function MorePage() {
  const router = useRouter();
  const { user, logout } = useAuth();

  const items = [
    { label: "Notices", icon: "📢", href: "/notices", desc: "View school notices and announcements" },
    { label: "Fees", icon: "💰", href: "/fees", desc: "Fee status and reminders" },
    { label: "Reports", icon: "📊", href: "/reports", desc: "Attendance, homework & fee reports" },
    { label: "Message Templates", icon: "💬", href: "/templates", desc: "WhatsApp message templates" },
    ...(user?.role === "admin"
      ? [{ label: "Admin Panel", icon: "⚙️", href: "/admin", desc: "Manage teachers, students & classes" }]
      : []),
  ];

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold text-slate-900 dark:text-white">More</h1>

      {/* User card */}
      <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
            <span className="text-lg font-semibold text-primary-600 dark:text-primary-400">
              {user?.displayName?.charAt(0).toUpperCase()}
            </span>
          </div>
          <div>
            <p className="font-semibold text-slate-900 dark:text-white">{user?.displayName}</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">{user?.email}</p>
            <span className="inline-flex px-2 py-0.5 rounded-md text-xs font-medium bg-primary-50 dark:bg-primary-950/30 text-primary-700 dark:text-primary-400 capitalize mt-1">
              {user?.role}
            </span>
          </div>
        </div>
      </div>

      {/* Menu items */}
      <div className="space-y-2">
        {items.map((item) => (
          <button
            key={item.href}
            onClick={() => router.push(item.href)}
            className="w-full bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 flex items-center gap-3 text-left card-hover"
          >
            <span className="text-2xl">{item.icon}</span>
            <div className="flex-1">
              <p className="text-sm font-medium text-slate-900 dark:text-white">{item.label}</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{item.desc}</p>
            </div>
            <svg className="w-4 h-4 text-slate-400" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
            </svg>
          </button>
        ))}
      </div>

      {/* Logout */}
      <button
        onClick={logout}
        className="w-full bg-white dark:bg-surface-900 rounded-xl border border-red-200 dark:border-red-800/50 p-4 flex items-center gap-3 text-left hover:bg-red-50 dark:hover:bg-red-950/20 transition-colors"
      >
        <span className="text-2xl">🚪</span>
        <div>
          <p className="text-sm font-medium text-danger-600 dark:text-danger-500">Sign Out</p>
          <p className="text-xs text-slate-500 dark:text-slate-400">Log out of your account</p>
        </div>
      </button>
    </div>
  );
}
