"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../layout";
import { SCHOOL_NAME, SCHOOL_SHORT_NAME, CLASSES } from "@/lib/constants";

interface DashboardData {
  role: string;
  // Admin fields
  totalTeachers?: number;
  totalStudents?: number;
  classWiseCounts?: { className: string; count: number }[];
  feeDueCount?: number;
  feeOverdueCount?: number;
  presentToday?: number;
  absentToday?: number;
  // Teacher fields
  assignedClasses?: string[];
  homeworkPending?: number;
  notices?: Array<{
    id: string;
    title: string;
    category: string;
    noticeDate: string;
    className: string | null;
  }>;
  recentNotices?: Array<{
    id: string;
    title: string;
    category: string;
    noticeDate: string;
    className: string | null;
  }>;
}

const categoryColors: Record<string, string> = {
  Holiday: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  Exam: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  PTM: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  Homework: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  Circular: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
  General: "bg-slate-100 text-slate-700 dark:bg-slate-700/30 dark:text-slate-400",
};

export default function DashboardPage() {
  const { user, assignedClasses } = useAuth();
  const router = useRouter();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      const res = await fetch("/api/dashboard");
      if (res.ok) {
        const d = await res.json();
        setData(d);
      }
    } catch (err) {
      console.error("Dashboard fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="p-4 lg:p-6 space-y-4">
        <div className="skeleton h-8 w-48"></div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="skeleton h-28 rounded-2xl"></div>
          ))}
        </div>
      </div>
    );
  }

  const isAdmin = user?.role === "admin";
  const notices = data?.notices || data?.recentNotices || [];

  return (
    <div className="p-4 lg:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
          Good {getGreeting()}, {user?.displayName?.split(" ")[0]} 👋
        </h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
          {SCHOOL_NAME}
        </p>
      </div>

      {/* Quick Stats */}
      {isAdmin ? (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <StatCard
              label="Total Teachers"
              value={data?.totalTeachers ?? 0}
              icon="👨‍🏫"
              color="bg-blue-50 dark:bg-blue-950/50"
              onClick={() => router.push("/admin")}
            />
            <StatCard
              label="Total Students"
              value={data?.totalStudents ?? 0}
              icon="👨‍🎓"
              color="bg-green-50 dark:bg-green-950/50"
              onClick={() => router.push("/students")}
            />
            <StatCard
              label="Fee Due"
              value={data?.feeDueCount ?? 0}
              icon="💰"
              color="bg-amber-50 dark:bg-amber-950/50"
              onClick={() => router.push("/fees")}
            />
            <StatCard
              label="Absent Today"
              value={data?.absentToday ?? 0}
              icon="📋"
              color="bg-red-50 dark:bg-red-950/50"
              onClick={() => router.push("/attendance")}
            />
          </div>

          {/* Class-wise Student Counts */}
          {data?.classWiseCounts && data.classWiseCounts.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-3">
                Students by Class
              </h2>
              <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4">
                  {(data.classWiseCounts as { className: string; count: number }[])
                    .sort((a, b) => (CLASSES as readonly string[]).indexOf(a.className) - (CLASSES as readonly string[]).indexOf(b.className))
                    .map((c) => (
                    <div
                      key={c.className}
                      className="p-3 border-b border-r border-slate-100 dark:border-slate-800 last:border-r-0"
                    >
                      <p className="text-xs text-slate-500 dark:text-slate-400">{c.className}</p>
                      <p className="text-lg font-bold text-slate-900 dark:text-white">{c.count}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
            <StatCard
              label="Absent Today"
              value={data?.absentToday ?? 0}
              icon="📋"
              color="bg-red-50 dark:bg-red-950/50"
              onClick={() => router.push("/attendance")}
            />
            <StatCard
              label="HW Pending"
              value={data?.homeworkPending ?? 0}
              icon="📚"
              color="bg-amber-50 dark:bg-amber-950/50"
              onClick={() => router.push("/homework")}
            />
            <StatCard
              label="Fee Due"
              value={data?.feeDueCount ?? 0}
              icon="💰"
              color="bg-orange-50 dark:bg-orange-950/50"
              onClick={() => router.push("/fees")}
            />
          </div>

          {/* Assigned Classes */}
          {assignedClasses.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-3">
                Your Classes
              </h2>
              <div className="flex flex-wrap gap-2">
                {assignedClasses.map((cls) => (
                  <button
                    key={cls}
                    onClick={() => router.push(`/attendance?class=${cls}`)}
                    className="px-4 py-2 rounded-xl bg-primary-50 dark:bg-primary-950/50 text-primary-700 dark:text-primary-300 text-sm font-medium hover:bg-primary-100 dark:hover:bg-primary-900/50 transition-colors"
                  >
                    {cls}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white mb-3">
              Quick Actions
            </h2>
            <div className="grid grid-cols-2 gap-3">
              <QuickAction
                label="Mark Attendance"
                icon="✅"
                onClick={() => router.push("/attendance")}
              />
              <QuickAction
                label="Assign Homework"
                icon="📝"
                onClick={() => router.push("/homework")}
              />
              <QuickAction
                label="Send Message"
                icon="💬"
                onClick={() => router.push("/templates")}
              />
              <QuickAction
                label="View Reports"
                icon="📊"
                onClick={() => router.push("/reports")}
              />
            </div>
          </div>
        </>
      )}

      {/* Recent Notices */}
      {notices.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white">
              Recent Notices
            </h2>
            <button
              onClick={() => router.push("/notices")}
              className="text-sm text-primary-600 dark:text-primary-400 font-medium hover:underline"
            >
              View All
            </button>
          </div>
          <div className="space-y-2">
            {notices.slice(0, 4).map((notice) => (
              <div
                key={notice.id}
                className="bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3 card-hover"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                      {notice.title}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-medium ${categoryColors[notice.category] || categoryColors.General}`}>
                        {notice.category}
                      </span>
                      <span className="text-xs text-slate-400">
                        {notice.noticeDate}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({
  label,
  value,
  icon,
  color,
  onClick,
}: {
  label: string;
  value: number;
  icon: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`${color} rounded-2xl p-4 text-left card-hover transition-all border border-transparent hover:border-slate-200 dark:hover:border-slate-700`}
    >
      <div className="text-2xl mb-2">{icon}</div>
      <p className="text-2xl font-bold text-slate-900 dark:text-white">{value}</p>
      <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">{label}</p>
    </button>
  );
}

function QuickAction({
  label,
  icon,
  onClick,
}: {
  label: string;
  icon: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 flex items-center gap-3 card-hover tap-highlight"
    >
      <span className="text-2xl">{icon}</span>
      <span className="text-sm font-medium text-slate-900 dark:text-white">{label}</span>
    </button>
  );
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Morning";
  if (hour < 17) return "Afternoon";
  return "Evening";
}
