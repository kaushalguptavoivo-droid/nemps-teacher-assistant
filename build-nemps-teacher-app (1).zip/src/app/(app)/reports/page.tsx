"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../layout";
import { CLASSES, MONTHS } from "@/lib/constants";

interface ReportRow {
  [key: string]: unknown;
}

export default function ReportsPage() {
  const { user, assignedClasses } = useAuth();
  const isAdmin = user?.role === "admin";
  const classes = isAdmin ? (CLASSES as readonly string[]) : assignedClasses;

  const [reportType, setReportType] = useState<"attendance" | "homework" | "fees">("attendance");
  const [selectedClass, setSelectedClass] = useState(classes[0] || "");
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [report, setReport] = useState<ReportRow[]>([]);
  const [summary, setSummary] = useState<Record<string, unknown> | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedClass) fetchReport();
  }, [reportType, selectedClass, selectedMonth, selectedYear]);

  const fetchReport = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/reports?type=${reportType}&class=${encodeURIComponent(selectedClass)}&month=${selectedMonth}&year=${selectedYear}`
      );
      if (res.ok) {
        const data = await res.json();
        setReport(data.report || []);
        setSummary(data.summary || null);
      }
    } catch (err) {
      console.error("Fetch report error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold text-slate-900 dark:text-white">Reports</h1>

      {/* Type selector */}
      <div className="flex gap-1 bg-slate-100 dark:bg-surface-800 rounded-xl p-1">
        {(["attendance", "homework", "fees"] as const).map((type) => (
          <button
            key={type}
            onClick={() => setReportType(type)}
            className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${
              reportType === type
                ? "bg-white dark:bg-surface-700 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400"
            }`}
          >
            {type}
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <select
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {classes.map((cls) => (
            <option key={cls} value={cls}>{cls}</option>
          ))}
        </select>
        <select
          value={selectedMonth}
          onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {MONTHS.map((m, i) => (
            <option key={i} value={i + 1}>{m}</option>
          ))}
        </select>
        <select
          value={selectedYear}
          onChange={(e) => setSelectedYear(parseInt(e.target.value))}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {[2024, 2025, 2026].map((y) => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
      </div>

      {/* Fee Summary */}
      {reportType === "fees" && summary && (
        <div className="flex gap-3">
          <div className="flex-1 bg-green-50 dark:bg-green-950/30 rounded-xl p-3 text-center">
            <p className="text-lg font-bold text-green-700 dark:text-green-400">{(summary as Record<string, number>).paidCount}</p>
            <p className="text-xs text-green-600 dark:text-green-500">Paid</p>
          </div>
          <div className="flex-1 bg-amber-50 dark:bg-amber-950/30 rounded-xl p-3 text-center">
            <p className="text-lg font-bold text-amber-700 dark:text-amber-400">{(summary as Record<string, number>).dueCount}</p>
            <p className="text-xs text-amber-600 dark:text-amber-500">Due</p>
          </div>
          <div className="flex-1 bg-red-50 dark:bg-red-950/30 rounded-xl p-3 text-center">
            <p className="text-lg font-bold text-red-700 dark:text-red-400">{(summary as Record<string, number>).overdueCount}</p>
            <p className="text-xs text-red-600 dark:text-red-500">Overdue</p>
          </div>
        </div>
      )}

      {/* Report Table */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="skeleton h-10 rounded-lg"></div>
          ))}
        </div>
      ) : report.length === 0 ? (
        <div className="text-center py-12 text-slate-500 dark:text-slate-400">
          <p className="text-4xl mb-2">📊</p>
          <p className="font-medium">No data available</p>
        </div>
      ) : (
        <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 dark:bg-surface-800 border-b border-slate-200 dark:border-slate-700">
                  {reportType === "attendance" && (
                    <>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase">Roll</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase">Name</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">Present</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">Absent</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">%</th>
                    </>
                  )}
                  {reportType === "homework" && (
                    <>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase">Roll</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase">Name</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">Done</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">Pending</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">%</th>
                    </>
                  )}
                  {reportType === "fees" && (
                    <>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase">Roll</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 uppercase">Name</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">Amount</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 uppercase">Status</th>
                    </>
                  )}
                </tr>
              </thead>
              <tbody>
                {report.map((row, i) => (
                  <tr key={i} className="border-b border-slate-100 dark:border-slate-800">
                    {reportType === "attendance" && (
                      <>
                        <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{String(row.rollNo)}</td>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{String(row.studentName)}</td>
                        <td className="px-4 py-3 text-center text-green-600">{String(row.presentCount)}</td>
                        <td className="px-4 py-3 text-center text-red-600">{String(row.absentCount)}</td>
                        <td className="px-4 py-3 text-center">
                          <PercentageBadge value={Number(row.percentage)} />
                        </td>
                      </>
                    )}
                    {reportType === "homework" && (
                      <>
                        <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{String(row.rollNo)}</td>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{String(row.studentName)}</td>
                        <td className="px-4 py-3 text-center text-green-600">{String(row.completed)}</td>
                        <td className="px-4 py-3 text-center text-amber-600">{String(row.pending)}</td>
                        <td className="px-4 py-3 text-center">
                          <PercentageBadge value={Number(row.percentage)} />
                        </td>
                      </>
                    )}
                    {reportType === "fees" && (
                      <>
                        <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{String(row.rollNo)}</td>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{String(row.studentName)}</td>
                        <td className="px-4 py-3 text-center">₹{String(row.totalAmount || "—")}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-flex px-2 py-0.5 rounded-md text-xs font-medium ${
                            row.status === "paid"
                              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                              : row.status === "overdue"
                              ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                              : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                          }`}>
                            {String(row.status)}
                          </span>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

function PercentageBadge({ value }: { value: number }) {
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-md text-xs font-medium ${
      value >= 75
        ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
        : value >= 50
        ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
        : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
    }`}>
      {value}%
    </span>
  );
}
