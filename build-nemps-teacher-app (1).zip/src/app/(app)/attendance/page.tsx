"use client";

import { useState, useEffect, useCallback } from "react";
import { useAuth } from "../layout";
import { CLASSES, MONTHS } from "@/lib/constants";

interface AttendanceRecord {
  studentId: string;
  studentName: string;
  rollNo: string;
  parentWhatsapp: string | null;
  status: "present" | "absent" | null;
  attendanceId: string | null;
  remarks: string | null;
}

interface MonthlyStat {
  studentId: string;
  studentName: string;
  rollNo: string;
  presentCount: number;
  absentCount: number;
  totalDays: number;
  percentage: number;
}

export default function AttendancePage() {
  const { user, assignedClasses } = useAuth();
  const isAdmin = user?.role === "admin";
  const classes = isAdmin ? (CLASSES as readonly string[]) : assignedClasses;

  const [selectedClass, setSelectedClass] = useState(classes[0] || "");
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [viewMode, setViewMode] = useState<"daily" | "monthly">("daily");
  const [monthlyStats, setMonthlyStats] = useState<MonthlyStat[]>([]);
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (selectedClass) {
      if (viewMode === "daily") fetchDailyAttendance();
      else fetchMonthlyReport();
    }
  }, [selectedClass, selectedDate, viewMode, selectedMonth, selectedYear]);

  const fetchDailyAttendance = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/attendance?class=${encodeURIComponent(selectedClass)}&date=${selectedDate}`);
      if (res.ok) {
        const data = await res.json();
        setRecords(data.attendance || []);
      }
    } catch (err) {
      console.error("Fetch attendance error:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMonthlyReport = async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/attendance?class=${encodeURIComponent(selectedClass)}&report=monthly&month=${selectedMonth}&year=${selectedYear}`
      );
      if (res.ok) {
        const data = await res.json();
        setMonthlyStats(data.stats || []);
      }
    } catch (err) {
      console.error("Fetch monthly report error:", err);
    } finally {
      setLoading(false);
    }
  };

  const toggleStatus = (studentId: string, status: "present" | "absent") => {
    setRecords((prev) =>
      prev.map((r) =>
        r.studentId === studentId
          ? { ...r, status: r.status === status ? null : status }
          : r
      )
    );
  };

  const markAllPresent = () => {
    setRecords((prev) =>
      prev.map((r) => ({ ...r, status: "present" as const }))
    );
  };

  const saveAttendance = async () => {
    setSaving(true);
    setMessage("");
    try {
      const toSave = records
        .filter((r) => r.status !== null)
        .map((r) => ({
          studentId: r.studentId,
          status: r.status,
          remarks: r.remarks,
        }));

      if (toSave.length === 0) {
        setMessage("No attendance to save");
        return;
      }

      const res = await fetch("/api/attendance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          className: selectedClass,
          date: selectedDate,
          records: toSave,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setMessage(`✅ Saved ${data.upserted} records`);
        fetchDailyAttendance();
      } else {
        setMessage("❌ Failed to save");
      }
    } catch {
      setMessage("❌ Network error");
    } finally {
      setSaving(false);
    }
  };

  const sendWhatsAppReminder = (phone: string | null, studentName: string) => {
    if (!phone) return;
    const msg = encodeURIComponent(
      `Dear Parent, your child ${studentName} of class ${selectedClass} was absent on ${selectedDate}. Please ensure regular attendance. - New Era Modern Public School, Vrindavan`
    );
    const cleanPhone = phone.replace(/\D/g, "");
    const phoneWithCode = cleanPhone.startsWith("91") ? cleanPhone : `91${cleanPhone}`;
    window.open(`https://wa.me/${phoneWithCode}?text=${msg}`, "_blank");
  };

  const presentCount = records.filter((r) => r.status === "present").length;
  const absentCount = records.filter((r) => r.status === "absent").length;
  const unmarkedCount = records.filter((r) => r.status === null).length;

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Attendance</h1>
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-surface-800 rounded-xl p-1">
          <button
            onClick={() => setViewMode("daily")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              viewMode === "daily"
                ? "bg-white dark:bg-surface-700 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400"
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setViewMode("monthly")}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              viewMode === "monthly"
                ? "bg-white dark:bg-surface-700 text-slate-900 dark:text-white shadow-sm"
                : "text-slate-500 dark:text-slate-400"
            }`}
          >
            Monthly
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {/* Class selector */}
        <select
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {classes.map((cls) => (
            <option key={cls} value={cls}>{cls}</option>
          ))}
        </select>

        {viewMode === "daily" ? (
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
        ) : (
          <>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {MONTHS.map((m, i) => (
                <option key={i} value={i + 1}>{m}</option>
              ))}
            </select>
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(parseInt(e.target.value))}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {[2024, 2025, 2026].map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </>
        )}
      </div>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="skeleton h-16 rounded-xl"></div>
          ))}
        </div>
      ) : viewMode === "daily" ? (
        <>
          {/* Summary Bar */}
          {records.length > 0 && (
            <div className="flex items-center gap-3 bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-3">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="text-sm text-slate-600 dark:text-slate-400">Present: <strong className="text-slate-900 dark:text-white">{presentCount}</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <span className="text-sm text-slate-600 dark:text-slate-400">Absent: <strong className="text-slate-900 dark:text-white">{absentCount}</strong></span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full bg-slate-300"></div>
                <span className="text-sm text-slate-600 dark:text-slate-400">Unmarked: <strong className="text-slate-900 dark:text-white">{unmarkedCount}</strong></span>
              </div>
              <div className="ml-auto">
                <button
                  onClick={markAllPresent}
                  className="text-xs text-primary-600 dark:text-primary-400 font-medium hover:underline"
                >
                  Mark All Present
                </button>
              </div>
            </div>
          )}

          {/* Student List */}
          {records.length === 0 ? (
            <div className="text-center py-12 text-slate-500 dark:text-slate-400">
              <p className="text-4xl mb-2">📋</p>
              <p className="font-medium">No students found</p>
              <p className="text-sm">Select a class to mark attendance</p>
            </div>
          ) : (
            <div className="space-y-2">
              {records.map((record, index) => (
                <div
                  key={record.studentId}
                  className={`bg-white dark:bg-surface-900 rounded-xl border transition-colors p-3 flex items-center gap-3 ${
                    record.status === "present"
                      ? "border-green-300 dark:border-green-800 bg-green-50/50 dark:bg-green-950/20"
                      : record.status === "absent"
                      ? "border-red-300 dark:border-red-800 bg-red-50/50 dark:bg-red-950/20"
                      : "border-slate-200 dark:border-slate-800"
                  }`}
                >
                  <span className="text-xs text-slate-400 w-6 text-center">{index + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                      {record.studentName}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Roll: {record.rollNo}
                    </p>
                  </div>

                  {/* Status Buttons */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => toggleStatus(record.studentId, "present")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        record.status === "present"
                          ? "bg-green-500 text-white shadow-sm"
                          : "bg-slate-100 dark:bg-surface-700 text-slate-500 dark:text-slate-400 hover:bg-green-100 dark:hover:bg-green-900/30"
                      }`}
                    >
                      P
                    </button>
                    <button
                      onClick={() => toggleStatus(record.studentId, "absent")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        record.status === "absent"
                          ? "bg-red-500 text-white shadow-sm"
                          : "bg-slate-100 dark:bg-surface-700 text-slate-500 dark:text-slate-400 hover:bg-red-100 dark:hover:bg-red-900/30"
                      }`}
                    >
                      A
                    </button>
                  </div>

                  {/* WhatsApp for absent students */}
                  {record.status === "absent" && record.parentWhatsapp && (
                    <button
                      onClick={() => sendWhatsAppReminder(record.parentWhatsapp, record.studentName)}
                      className="p-1.5 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors"
                      title="Send WhatsApp reminder"
                    >
                      <svg className="w-4 h-4 text-green-600" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Save Button */}
          {records.length > 0 && (
            <div className="sticky bottom-20 lg:bottom-4 z-10">
              <button
                onClick={saveAttendance}
                disabled={saving}
                className="w-full py-3.5 rounded-2xl bg-primary-600 hover:bg-primary-700 active:bg-primary-800 text-white font-semibold text-sm transition-colors disabled:opacity-50 shadow-lg shadow-primary-600/20"
              >
                {saving ? "Saving..." : "Save Attendance"}
              </button>
            </div>
          )}
        </>
      ) : (
        /* Monthly Report View */
        <>
          {monthlyStats.length === 0 ? (
            <div className="text-center py-12 text-slate-500 dark:text-slate-400">
              <p className="text-4xl mb-2">📊</p>
              <p className="font-medium">No data for this month</p>
            </div>
          ) : (
            <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-surface-800 border-b border-slate-200 dark:border-slate-700">
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">Roll</th>
                      <th className="text-left px-4 py-3 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">Name</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">Present</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">Absent</th>
                      <th className="text-center px-4 py-3 text-xs font-medium text-slate-500 dark:text-slate-400 uppercase">%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {monthlyStats.map((stat) => (
                      <tr key={stat.studentId} className="border-b border-slate-100 dark:border-slate-800">
                        <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{stat.rollNo}</td>
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">{stat.studentName}</td>
                        <td className="px-4 py-3 text-center text-green-600 dark:text-green-400">{stat.presentCount}</td>
                        <td className="px-4 py-3 text-center text-red-600 dark:text-red-400">{stat.absentCount}</td>
                        <td className="px-4 py-3 text-center">
                          <span className={`inline-flex px-2 py-0.5 rounded-md text-xs font-medium ${
                            stat.percentage >= 75
                              ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                              : stat.percentage >= 50
                              ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                              : "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                          }`}>
                            {stat.percentage}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
