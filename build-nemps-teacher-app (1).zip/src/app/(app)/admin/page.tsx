"use client";

import { useState, useEffect, useRef } from "react";
import { useAuth } from "../layout";
import { CLASSES } from "@/lib/constants";

interface Teacher {
  id: string;
  email: string;
  displayName: string;
  phone: string | null;
  isActive: boolean;
  classes: string[];
}

export default function AdminPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState<"teachers" | "import">("teachers");
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  // Create teacher form
  const [showCreate, setShowCreate] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({
    email: "",
    password: "",
    displayName: "",
    phone: "",
    classes: [] as string[],
  });

  // Import
  const fileRef = useRef<HTMLInputElement>(null);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{ imported: number; skipped: number; errors: string[] } | null>(null);

  useEffect(() => {
    fetchTeachers();
  }, []);

  const fetchTeachers = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/teachers");
      if (res.ok) {
        const data = await res.json();
        setTeachers(data.teachers || []);
      }
    } catch (err) {
      console.error("Fetch teachers error:", err);
    } finally {
      setLoading(false);
    }
  };

  const createTeacher = async () => {
    if (!form.email || !form.password || !form.displayName) {
      setMessage("❌ Email, password, and name are required");
      return;
    }
    try {
      const res = await fetch("/api/teachers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (res.ok) {
        setMessage("✅ Teacher created");
        setShowCreate(false);
        resetForm();
        fetchTeachers();
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Network error");
    }
  };

  const updateTeacher = async () => {
    if (!editId) return;
    try {
      const updates: Record<string, unknown> = {
        displayName: form.displayName,
        phone: form.phone || null,
        classes: form.classes,
      };
      if (form.password) updates.password = form.password;

      const res = await fetch("/api/teachers", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: editId, ...updates }),
      });
      if (res.ok) {
        setMessage("✅ Teacher updated");
        setEditId(null);
        resetForm();
        fetchTeachers();
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Network error");
    }
  };

  const toggleClassAssignment = (cls: string) => {
    setForm((prev) => ({
      ...prev,
      classes: prev.classes.includes(cls)
        ? prev.classes.filter((c) => c !== cls)
        : [...prev.classes, cls],
    }));
  };

  const editTeacher = (teacher: Teacher) => {
    setEditId(teacher.id);
    setForm({
      email: teacher.email,
      password: "",
      displayName: teacher.displayName,
      phone: teacher.phone || "",
      classes: teacher.classes,
    });
    setShowCreate(false);
  };

  const resetForm = () => {
    setForm({ email: "", password: "", displayName: "", phone: "", classes: [] });
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    setImportResult(null);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/students/import", {
        method: "POST",
        body: formData,
      });
      if (res.ok) {
        const data = await res.json();
        setImportResult(data);
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Import failed");
    } finally {
      setImporting(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  if (user?.role !== "admin") {
    return (
      <div className="p-4 text-center text-slate-500 dark:text-slate-400">
        <p>Access denied. Admin only.</p>
      </div>
    );
  }

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold text-slate-900 dark:text-white">Admin Panel</h1>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 dark:bg-surface-800 rounded-xl p-1">
        <button
          onClick={() => setTab("teachers")}
          className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
            tab === "teachers"
              ? "bg-white dark:bg-surface-700 text-slate-900 dark:text-white shadow-sm"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          Teachers
        </button>
        <button
          onClick={() => setTab("import")}
          className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
            tab === "import"
              ? "bg-white dark:bg-surface-700 text-slate-900 dark:text-white shadow-sm"
              : "text-slate-500 dark:text-slate-400"
          }`}
        >
          Import Students
        </button>
      </div>

      {tab === "teachers" && (
        <>
          {/* Create/Edit Form */}
          {(showCreate || editId) && (
            <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
              <h3 className="font-semibold text-slate-900 dark:text-white">
                {editId ? "Edit Teacher" : "Add New Teacher"}
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="email"
                  placeholder="Email *"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  disabled={!!editId}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white disabled:opacity-50"
                />
                <input
                  type="password"
                  placeholder={editId ? "New password (optional)" : "Password *"}
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Display Name *"
                  value={form.displayName}
                  onChange={(e) => setForm({ ...form, displayName: e.target.value })}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
                />
                <input
                  type="text"
                  placeholder="Phone"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
                />
              </div>

              {/* Class assignments */}
              <div>
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Assign Classes</p>
                <div className="flex flex-wrap gap-2">
                  {CLASSES.map((cls) => (
                    <button
                      key={cls}
                      onClick={() => toggleClassAssignment(cls)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                        form.classes.includes(cls)
                          ? "bg-primary-600 text-white"
                          : "bg-slate-100 dark:bg-surface-800 text-slate-500 dark:text-slate-400"
                      }`}
                    >
                      {cls}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={editId ? updateTeacher : createTeacher}
                  className="flex-1 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700"
                >
                  {editId ? "Update" : "Create"} Teacher
                </button>
                <button
                  onClick={() => { setEditId(null); setShowCreate(false); resetForm(); }}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-400"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Add button */}
          {!showCreate && !editId && (
            <button
              onClick={() => { setShowCreate(true); resetForm(); }}
              className="w-full py-3 rounded-xl border-2 border-dashed border-slate-300 dark:border-slate-700 text-sm text-slate-500 dark:text-slate-400 hover:border-primary-400 hover:text-primary-600 transition-colors"
            >
              + Add New Teacher
            </button>
          )}

          {/* Teacher List */}
          {loading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="skeleton h-20 rounded-xl"></div>
              ))}
            </div>
          ) : teachers.length === 0 ? (
            <div className="text-center py-12 text-slate-500 dark:text-slate-400">
              <p className="text-4xl mb-2">👨‍🏫</p>
              <p className="font-medium">No teachers yet</p>
            </div>
          ) : (
            <div className="space-y-2">
              {teachers.map((teacher) => (
                <div
                  key={teacher.id}
                  className="bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
                          <span className="text-sm font-semibold text-primary-600 dark:text-primary-400">
                            {teacher.displayName.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-slate-900 dark:text-white">{teacher.displayName}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{teacher.email}</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1 mt-2 ml-10">
                        {teacher.classes.length > 0 ? (
                          teacher.classes.map((cls) => (
                            <span key={cls} className="px-2 py-0.5 rounded-md bg-primary-50 dark:bg-primary-950/30 text-primary-700 dark:text-primary-400 text-[10px] font-medium">
                              {cls}
                            </span>
                          ))
                        ) : (
                          <span className="text-xs text-slate-400">No classes assigned</span>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => editTeacher(teacher)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-surface-800 text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-surface-700"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {tab === "import" && (
        <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6">
          <h3 className="font-semibold text-slate-900 dark:text-white mb-2">Import Students from Excel</h3>
          <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
            Upload an Excel file (.xlsx) with columns: roll_no, student_name, father_name, mother_name, parent_whatsapp, alternate_phone, dob, address, class_name
          </p>

          <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 text-center">
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleImport}
              className="hidden"
              id="file-input"
            />
            <label
              htmlFor="file-input"
              className="cursor-pointer inline-flex flex-col items-center"
            >
              <svg className="w-10 h-10 text-slate-400 mb-2" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
              </svg>
              <span className="text-sm text-slate-600 dark:text-slate-400 font-medium">
                {importing ? "Importing..." : "Click to upload Excel file"}
              </span>
            </label>
          </div>

          {importResult && (
            <div className="mt-4 p-4 bg-slate-50 dark:bg-surface-800 rounded-xl">
              <div className="flex gap-4 mb-2">
                <span className="text-sm text-green-600 dark:text-green-400 font-medium">✅ Imported: {importResult.imported}</span>
                <span className="text-sm text-amber-600 dark:text-amber-400 font-medium">⚠️ Skipped: {importResult.skipped}</span>
              </div>
              {importResult.errors.length > 0 && (
                <div className="mt-2 space-y-1">
                  {importResult.errors.slice(0, 10).map((err, i) => (
                    <p key={i} className="text-xs text-red-600 dark:text-red-400">{err}</p>
                  ))}
                  {importResult.errors.length > 10 && (
                    <p className="text-xs text-slate-400">...and {importResult.errors.length - 10} more errors</p>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
