"use client";

import { useState, useEffect } from "react";
import { useAuth } from "../layout";
import { CLASSES, SUBJECTS } from "@/lib/constants";

interface HomeworkItem {
  id: string;
  className: string;
  subject: string;
  homeworkDate: string;
  title: string;
  description: string | null;
  createdBy: string;
}

interface HomeworkStatusItem {
  id: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  parentWhatsapp: string | null;
  status: "completed" | "pending" | "not_checked";
  checkedBy: string | null;
  checkedAt: string | null;
  remarks: string | null;
}

export default function HomeworkPage() {
  const { user, assignedClasses } = useAuth();
  const isAdmin = user?.role === "admin";
  const classes = isAdmin ? (CLASSES as readonly string[]) : assignedClasses;

  const [selectedClass, setSelectedClass] = useState(classes[0] || "");
  const [selectedSubject, setSelectedSubject] = useState("");
  const [homeworkList, setHomeworkList] = useState<HomeworkItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedHomework, setSelectedHomework] = useState<string | null>(null);
  const [statuses, setStatuses] = useState<HomeworkStatusItem[]>([]);
  const [statusesLoading, setStatusesLoading] = useState(false);

  // Create form
  const [newTitle, setNewTitle] = useState("");
  const [newDescription, setNewDescription] = useState("");
  const [newSubject, setNewSubject] = useState<string>(SUBJECTS[0]);
  const [newDate, setNewDate] = useState(new Date().toISOString().split("T")[0]);
  const [creating, setCreating] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (selectedClass) fetchHomework();
  }, [selectedClass, selectedSubject]);

  const fetchHomework = async () => {
    setLoading(true);
    try {
      let url = `/api/homework?class=${encodeURIComponent(selectedClass)}`;
      if (selectedSubject) url += `&subject=${encodeURIComponent(selectedSubject)}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setHomeworkList(data.homework || []);
      }
    } catch (err) {
      console.error("Fetch homework error:", err);
    } finally {
      setLoading(false);
    }
  };

  const fetchHomeworkStatus = async (homeworkId: string) => {
    setStatusesLoading(true);
    setSelectedHomework(homeworkId);
    try {
      const res = await fetch(`/api/homework?id=${homeworkId}&includeStatus=true`);
      if (res.ok) {
        const data = await res.json();
        setStatuses(data.statuses || []);
      }
    } catch (err) {
      console.error("Fetch status error:", err);
    } finally {
      setStatusesLoading(false);
    }
  };

  const createHomework = async () => {
    if (!newTitle || !selectedClass || !newSubject || !newDate) return;
    setCreating(true);
    try {
      const res = await fetch("/api/homework", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          className: selectedClass,
          subject: newSubject,
          homeworkDate: newDate,
          title: newTitle,
          description: newDescription,
        }),
      });
      if (res.ok) {
        setMessage("✅ Homework created");
        setShowCreate(false);
        setNewTitle("");
        setNewDescription("");
        fetchHomework();
      } else {
        const data = await res.json();
        setMessage(`❌ ${data.error}`);
      }
    } catch {
      setMessage("❌ Network error");
    } finally {
      setCreating(false);
    }
  };

  const updateStatus = async (homeworkId: string, studentId: string, status: "completed" | "pending" | "not_checked") => {
    try {
      await fetch("/api/homework", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "status", homeworkId, studentId, status }),
      });
      setStatuses((prev) =>
        prev.map((s) => (s.studentId === studentId ? { ...s, status } : s))
      );
    } catch (err) {
      console.error("Update status error:", err);
    }
  };

  const sendWhatsAppReminder = (phone: string | null, studentName: string) => {
    if (!phone) return;
    const msg = encodeURIComponent(
      `Dear Parent, ${studentName} has pending homework. Please ensure completion. - New Era Modern Public School, Vrindavan`
    );
    const cleanPhone = phone.replace(/\D/g, "");
    const phoneWithCode = cleanPhone.startsWith("91") ? cleanPhone : `91${cleanPhone}`;
    window.open(`https://wa.me/${phoneWithCode}?text=${msg}`, "_blank");
  };

  const subjectColors: Record<string, string> = {
    Hindi: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
    English: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    Math: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
    Science: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
    EVS: "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400",
    SST: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
    Sanskrit: "bg-pink-100 text-pink-700 dark:bg-pink-900/30 dark:text-pink-400",
    Computer: "bg-cyan-100 text-cyan-700 dark:bg-cyan-900/30 dark:text-cyan-400",
    GK: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400",
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white">Homework</h1>
        <button
          onClick={() => { setShowCreate(true); setSelectedHomework(null); }}
          className="px-4 py-2 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 transition-colors"
        >
          + Create
        </button>
      </div>

      {message && (
        <div className="p-3 bg-primary-50 dark:bg-primary-950/30 rounded-xl text-sm text-primary-700 dark:text-primary-300">
          {message}
        </div>
      )}

      {/* Create Form */}
      {showCreate && (
        <div className="bg-white dark:bg-surface-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
          <h3 className="font-semibold text-slate-900 dark:text-white">New Homework</h3>
          <div className="grid grid-cols-2 gap-3">
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {classes.map((cls) => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>
            <select
              value={newSubject}
              onChange={(e) => setNewSubject(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
            >
              {SUBJECTS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <input
            type="date"
            value={newDate}
            onChange={(e) => setNewDate(e.target.value)}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Homework title"
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
          />
          <textarea
            value={newDescription}
            onChange={(e) => setNewDescription(e.target.value)}
            placeholder="Description (optional)"
            rows={2}
            className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white resize-none"
          />
          <div className="flex gap-2">
            <button
              onClick={createHomework}
              disabled={creating}
              className="flex-1 py-2.5 rounded-xl bg-primary-600 text-white text-sm font-medium hover:bg-primary-700 disabled:opacity-50"
            >
              {creating ? "Creating..." : "Create Homework"}
            </button>
            <button
              onClick={() => setShowCreate(false)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm text-slate-600 dark:text-slate-400"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        <select
          value={selectedClass}
          onChange={(e) => setSelectedClass(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          {classes.map((cls) => (
            <option key={cls} value={cls}>{cls}</option>
          ))}
        </select>
        <select
          value={selectedSubject}
          onChange={(e) => setSelectedSubject(e.target.value)}
          className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-800 text-sm text-slate-900 dark:text-white"
        >
          <option value="">All Subjects</option>
          {SUBJECTS.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      {/* Homework List or Status Detail */}
      {selectedHomework ? (
        <div>
          <button
            onClick={() => setSelectedHomework(null)}
            className="text-sm text-primary-600 dark:text-primary-400 font-medium mb-3 hover:underline"
          >
            ← Back to list
          </button>
          {statusesLoading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="skeleton h-14 rounded-xl"></div>
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {statuses.map((s) => (
                <div
                  key={s.id}
                  className={`bg-white dark:bg-surface-900 rounded-xl border p-3 flex items-center gap-3 ${
                    s.status === "completed"
                      ? "border-green-200 dark:border-green-800"
                      : s.status === "pending"
                      ? "border-amber-200 dark:border-amber-800"
                      : "border-slate-200 dark:border-slate-800"
                  }`}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-white truncate">{s.studentName}</p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">Roll: {s.rollNo}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    {(["completed", "pending", "not_checked"] as const).map((st) => (
                      <button
                        key={st}
                        onClick={() => updateStatus(selectedHomework, s.studentId, st)}
                        className={`px-2 py-1 rounded-lg text-[10px] font-semibold transition-all ${
                          s.status === st
                            ? st === "completed"
                              ? "bg-green-500 text-white"
                              : st === "pending"
                              ? "bg-amber-500 text-white"
                              : "bg-slate-500 text-white"
                            : "bg-slate-100 dark:bg-surface-700 text-slate-500"
                        }`}
                      >
                        {st === "not_checked" ? "NC" : st === "completed" ? "✓" : "!"}
                      </button>
                    ))}
                  </div>
                  {s.status === "pending" && s.parentWhatsapp && (
                    <button
                      onClick={() => sendWhatsAppReminder(s.parentWhatsapp, s.studentName)}
                      className="p-1.5 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30"
                    >
                      <svg className="w-4 h-4 text-green-600" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ) : loading ? (
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="skeleton h-20 rounded-xl"></div>
          ))}
        </div>
      ) : homeworkList.length === 0 ? (
        <div className="text-center py-12 text-slate-500 dark:text-slate-400">
          <p className="text-4xl mb-2">📚</p>
          <p className="font-medium">No homework assigned</p>
          <p className="text-sm">Create homework for this class</p>
        </div>
      ) : (
        <div className="space-y-2">
          {homeworkList.map((hw) => (
            <button
              key={hw.id}
              onClick={() => fetchHomeworkStatus(hw.id)}
              className="w-full bg-white dark:bg-surface-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 text-left card-hover"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-900 dark:text-white">{hw.title}</p>
                  {hw.description && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">{hw.description}</p>
                  )}
                </div>
                <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-medium ${subjectColors[hw.subject] || "bg-slate-100 text-slate-600"}`}>
                  {hw.subject}
                </span>
              </div>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-xs text-slate-400">{hw.className}</span>
                <span className="text-xs text-slate-400">{hw.homeworkDate}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
