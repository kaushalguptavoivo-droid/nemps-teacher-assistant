# 🏫 NEMPS Teacher Assistant

**New Era Modern Public School, Vrindavan** — Teacher productivity web application

![Next.js](https://img.shields.io/badge/Next.js-16-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5.9-blue) ![PostgreSQL](https://img.shields.io/badge/PostgreSQL-Supabase-336791) ![Tailwind](https://img.shields.io/badge/Tailwind_CSS-4-06B6D4)

---

## 🚀 Quick Start (Local Development)

### 1. Clone & Install
```bash
git clone https://github.com/your-username/nemps-teacher-assistant.git
cd nemps-teacher-assistant
npm install
```

### 2. Setup Environment
```bash
cp .env.example .env
# Edit .env with your DATABASE_URL and JWT_SECRET
```

### 3. Setup Database
```bash
# Push schema to your PostgreSQL database
npx drizzle-kit push

# Seed the database
psql <your-database-url> -f supabase/schema.sql
```

### 4. Generate Password Hashes
After seeding, regenerate password hashes with bcrypt:
```bash
node -e "
const bcrypt = require('bcryptjs');
async function main() {
  console.log('admin123:', await bcrypt.hash('admin123', 12));
  console.log('teacher123:', await bcrypt.hash('teacher123', 12));
}
main();
"
```
Then update in database:
```sql
UPDATE users SET password_hash = '<admin-hash>' WHERE email = 'admin@nemps';
UPDATE users SET password_hash = '<teacher-hash>' WHERE email = 'teacher@nemps';
```

### 5. Run
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000)

---

## 🌐 Vercel + Supabase Deployment (Production)

### Step 1: Create Supabase Project

1. Go to [supabase.com](https://supabase.com) → **New Project**
2. Project name: `nemps-teacher-assistant`
3. Database password: `Kaushal@2024`
4. Region: **Mumbai (ap-south-1)** — closest to Vrindavan
5. Wait for project to be ready (~2 minutes)

### Step 2: Run Schema in Supabase

1. Go to **SQL Editor** in your Supabase dashboard
2. Copy the entire contents of `supabase/schema.sql`
3. Paste and click **Run**
4. You should see "Success" — all tables, indexes, RLS policies, and seed data are created

### Step 3: Get Database Connection String

1. Go to **Settings → Database** in Supabase dashboard
2. Scroll to **Connection string** → **URI** tab
3. Copy the connection string. It looks like:
   ```
   postgresql://postgres:Kaushal%402024@db.fdvfmoxcbkdisgnhplaa.supabase.co:5432/postgres
   ```
   > Note: `@` in password is URL-encoded as `%40`

### Step 4: Generate JWT Secret
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
Copy the output — this is your `JWT_SECRET`

### Step 5: Push to GitHub
```bash
git init
git add .
git commit -m "🏫 NEMPS Teacher Assistant - Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/nemps-teacher-assistant.git
git push -u origin main
```

### Step 6: Deploy on Vercel

1. Go to [vercel.com](https://vercel.com) → **Add New** → **Project**
2. Import your GitHub repository
3. Framework Preset: **Next.js** (auto-detected)
4. Add **Environment Variables**:

| Key | Value |
|-----|-------|
| `DATABASE_URL` | `postgresql://postgres:Kaushal%402024@db.fdvfmoxcbkdisgnhplaa.supabase.co:5432/postgres` |
| `JWT_SECRET` | `<the-hex-string-you-generated>` |

5. Click **Deploy**
6. Wait ~2 minutes for build to complete
7. Your app is live! 🎉

### Step 7: Update Password Hashes in Supabase

1. Run this in your local terminal:
```bash
node -e "
const bcrypt = require('bcryptjs');
async function main() {
  console.log('admin123:', await bcrypt.hash('admin123', 12));
  console.log('teacher123:', await bcrypt.hash('teacher123', 12));
}
main();
"
```

2. Go to **SQL Editor** in Supabase
3. Run:
```sql
UPDATE users SET password_hash = '<admin123-hash>' WHERE email = 'admin@nemps';
UPDATE users SET password_hash = '<teacher123-hash>' WHERE email = 'teacher@nemps';
```

### Step 8: Add to Android Home Screen

1. Open your Vercel URL in **Chrome** on your Android phone
2. Tap the **⋮ menu** → **"Add to Home Screen"**
3. Name it **"NEMPS"** → **Add**
4. App icon appears on home screen — opens full-screen like a native app! 📱

---

## 🔑 Demo Credentials

| Role | Email | Password |
|------|-------|----------|
| **Admin** | `admin@nemps` | `admin123` |
| **Teacher** | `teacher@nemps` | `teacher123` |

> ⚠️ Change these passwords after first login in production!

---

## 📊 Features

| Feature | Admin | Teacher |
|---------|:-----:|:-------:|
| School-wide dashboard | ✅ | — |
| Assigned classes dashboard | — | ✅ |
| Mark attendance (one-tap P/A) | ✅ | ✅ |
| Monthly attendance report | ✅ | ✅ |
| Create homework | ✅ | ✅ |
| Track homework per student | ✅ | ✅ |
| Student profiles | ✅ All | ✅ Assigned |
| Fee generation & tracking | ✅ | ✅ View |
| Mark fee as paid | ✅ | — |
| Create & manage notices | ✅ | — |
| View relevant notices | ✅ | ✅ |
| Edit message templates | ✅ | — |
| Use message templates | ✅ | ✅ |
| WhatsApp prefilled messages | ✅ | ✅ |
| Reports (attendance/hw/fees) | ✅ | ✅ |
| Teacher management | ✅ | — |
| Student import (Excel) | ✅ | — |
| Dark / Light mode | ✅ | ✅ |

---

## 🏗️ Tech Stack

| Technology | Purpose |
|-----------|---------|
| **Next.js 16** | Full-stack React framework (App Router) |
| **PostgreSQL** | Database (via Supabase) |
| **Drizzle ORM** | Type-safe database queries |
| **Tailwind CSS v4** | Utility-first styling (Material 3 design) |
| **TypeScript** | Type safety throughout |
| **JWT + bcrypt** | Authentication & password hashing |
| **XLSX** | Excel file parsing for student import |

---

## 📁 Project Structure

```
nemps-teacher-assistant/
├── src/
│   ├── app/
│   │   ├── (app)/              # Protected app pages
│   │   │   ├── layout.tsx      # Auth context + navigation shell
│   │   │   ├── dashboard/      # Admin & Teacher dashboards
│   │   │   ├── attendance/     # Mark attendance, monthly reports
│   │   │   ├── homework/       # Create & track homework
│   │   │   ├── students/       # Student list & profiles
│   │   │   ├── fees/           # Fee management & reminders
│   │   │   ├── notices/        # School notices (6 categories)
│   │   │   ├── templates/      # WhatsApp message templates
│   │   │   ├── reports/        # Attendance, homework, fee reports
│   │   │   ├── admin/          # Teacher management + Excel import
│   │   │   └── more/           # Settings & navigation
│   │   ├── login/              # Login page
│   │   └── api/                # 11 REST API routes
│   │       ├── auth/           # Login/logout/session
│   │       ├── dashboard/      # Aggregated stats
│   │       ├── students/       # CRUD + import
│   │       ├── attendance/     # Daily + monthly
│   │       ├── homework/       # Create + status
│   │       ├── fees/           # Generate + update
│   │       ├── notices/        # CRUD
│   │       ├── templates/      # Read + update
│   │       ├── reports/        # 3 report types
│   │       └── teachers/       # CRUD (admin)
│   ├── db/
│   │   ├── index.ts            # Drizzle client
│   │   └── schema.ts           # 9 tables with enums
│   ├── lib/
│   │   ├── auth.ts             # JWT + bcrypt utilities
│   │   └── constants.ts        # Classes, subjects, fee rules
│   └── middleware.ts           # Auth guard + role-based routing
├── supabase/
│   └── schema.sql              # Complete DB schema + RLS + seed
├── public/                     # Static assets
├── .env.example                # Environment template
├── vercel.json                 # Vercel deployment config
├── drizzle.config.json         # Drizzle ORM config
├── next.config.ts              # Next.js config
├── tsconfig.json               # TypeScript config
└── package.json
```

---

## 🏫 School Configuration

### Classes (11)
Nursery, Prep, Pre1st, 1st, 2nd, 3rd, 4th, 5th, 6th, 7th, 8th

### Subjects (9)
Hindi, English, Math, Science, EVS, SST, Sanskrit, Computer, GK

### Fee Rules
- Monthly fee cycle
- Due date: **7th** of every month
- Overdue after: **15th** of every month
- No fine calculation
- Exam fee: **₹100** (2 times/year — March & September)

### Notice Categories (6)
Holiday, Exam, PTM, Homework, Circular, General

### WhatsApp Template Placeholders
`{student_name}`, `{class_name}`, `{date}`, `{fee_month}`, `{amount}`, `{school_name}`

---

## 📱 Mobile Usage (Android)

This is a **Progressive Web App** — no APK needed:

1. Open the Vercel URL in Chrome
2. Menu → **"Add to Home Screen"**
3. App icon on home screen
4. Opens full-screen — works like a native app
5. Works offline for cached data
6. Fast one-tap attendance marking

---

## 🔒 Security Notes

- Passwords hashed with **bcrypt** (12 salt rounds)
- Session tokens via **JWT** (7-day expiry)
- **httpOnly** cookies — not accessible from JavaScript
- Middleware-based **role-based access control**
- Admin-only routes protected at server level
- Teachers can only access **assigned classes**
- **RLS enabled** on all Supabase tables

---

## 📝 License

This project is built for **New Era Modern Public School, Vrindavan**.
All rights reserved © 2025
