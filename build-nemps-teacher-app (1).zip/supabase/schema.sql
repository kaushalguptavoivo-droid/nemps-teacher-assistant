-- ════════════════════════════════════════════════════════════════════════════
-- NEMPS Teacher Assistant — Supabase Database Schema
-- New Era Modern Public School, Vrindavan
-- ════════════════════════════════════════════════════════════════════════════
-- Run this SQL in Supabase SQL Editor (https://supabase.com/dashboard → SQL Editor)
-- Execute the entire file at once or in sections as marked below.
-- ════════════════════════════════════════════════════════════════════════════

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SECTION 1: ENUMS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DO $$ BEGIN
  -- Role enum
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'role') THEN
    CREATE TYPE role AS ENUM ('admin', 'teacher');
  END IF;

  -- Attendance status enum
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'attendance_status') THEN
    CREATE TYPE attendance_status AS ENUM ('present', 'absent');
  END IF;

  -- Homework completion enum (named differently to avoid table name conflict)
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'homework_completion') THEN
    CREATE TYPE homework_completion AS ENUM ('completed', 'pending', 'not_checked');
  END IF;

  -- Fee status enum
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'fee_status') THEN
    CREATE TYPE fee_status AS ENUM ('paid', 'due', 'overdue');
  END IF;

  -- Notice category enum
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'notice_category') THEN
    CREATE TYPE notice_category AS ENUM ('Holiday', 'Exam', 'PTM', 'Homework', 'Circular', 'General');
  END IF;
END $$;

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SECTION 2: TABLES
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

-- ─── Users ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name VARCHAR(255) NOT NULL,
  role role NOT NULL DEFAULT 'teacher',
  phone VARCHAR(20),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Class Assignments ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS class_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  class_name VARCHAR(50) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Students ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS students (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  roll_no VARCHAR(20) NOT NULL,
  student_name VARCHAR(255) NOT NULL,
  father_name VARCHAR(255),
  mother_name VARCHAR(255),
  parent_whatsapp VARCHAR(20),
  alternate_phone VARCHAR(20),
  dob DATE,
  address TEXT,
  class_name VARCHAR(50) NOT NULL,
  photo_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Attendance ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS attendance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  class_name VARCHAR(50) NOT NULL,
  attendance_date DATE NOT NULL,
  status attendance_status NOT NULL,
  marked_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  remarks TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Homework ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS homework (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  class_name VARCHAR(50) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  homework_date DATE NOT NULL,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Homework Status ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS homework_status (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  homework_id UUID NOT NULL REFERENCES homework(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  status homework_completion NOT NULL DEFAULT 'not_checked',
  checked_by UUID REFERENCES users(id) ON DELETE SET NULL,
  checked_at TIMESTAMPTZ,
  remarks TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Fees ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES students(id) ON DELETE CASCADE,
  fee_month INTEGER NOT NULL,
  fee_year INTEGER NOT NULL,
  monthly_fee_amount NUMERIC(10,2),
  exam_fee_amount NUMERIC(10,2),
  total_amount NUMERIC(10,2),
  due_date DATE NOT NULL,
  paid_date DATE,
  status fee_status NOT NULL DEFAULT 'due',
  reminder_count INTEGER NOT NULL DEFAULT 0,
  last_reminder_at TIMESTAMPTZ,
  remarks TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Notices ──────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR(500) NOT NULL,
  body TEXT NOT NULL,
  category notice_category NOT NULL,
  class_name VARCHAR(50),
  notice_date DATE NOT NULL,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ─── Message Templates ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS message_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key VARCHAR(100) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  body_en TEXT NOT NULL,
  body_hi TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SECTION 3: INDEXES
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

-- Attendance lookups
CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON attendance(student_id, attendance_date);
CREATE INDEX IF NOT EXISTS idx_attendance_class_date ON attendance(class_name, attendance_date);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(attendance_date);

-- Students by class
CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_name);
CREATE INDEX IF NOT EXISTS idx_students_roll_class ON students(roll_no, class_name);

-- Homework by class
CREATE INDEX IF NOT EXISTS idx_homework_class ON homework(class_name);
CREATE INDEX IF NOT EXISTS idx_homework_date ON homework(homework_date);

-- Homework status
CREATE INDEX IF NOT EXISTS idx_hw_status_homework ON homework_status(homework_id);
CREATE INDEX IF NOT EXISTS idx_hw_status_student ON homework_status(student_id);

-- Fees
CREATE INDEX IF NOT EXISTS idx_fees_student ON fees(student_id);
CREATE INDEX IF NOT EXISTS idx_fees_status ON fees(status);
CREATE INDEX IF NOT EXISTS idx_fees_month_year ON fees(fee_month, fee_year);

-- Notices
CREATE INDEX IF NOT EXISTS idx_notices_active ON notices(is_active);
CREATE INDEX IF NOT EXISTS idx_notices_class ON notices(class_name);
CREATE INDEX IF NOT EXISTS idx_notices_date ON notices(notice_date);

-- Class assignments
CREATE INDEX IF NOT EXISTS idx_class_assignments_user ON class_assignments(user_id);

-- Users
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SECTION 4: ROW LEVEL SECURITY (RLS)
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE class_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE homework ENABLE ROW LEVEL SECURITY;
ALTER TABLE homework_status ENABLE ROW LEVEL SECURITY;
ALTER TABLE fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE message_templates ENABLE ROW LEVEL SECURITY;

-- ─── Users RLS ────────────────────────────────────────────────────────────
-- Anyone can read their own profile
CREATE POLICY "Users can read own profile" ON users
  FOR SELECT USING (true);

-- Only admin can insert users
CREATE POLICY "Admin can insert users" ON users
  FOR INSERT WITH CHECK (true);

-- Users can update own profile; admin can update any
CREATE POLICY "Users can update own profile" ON users
  FOR UPDATE USING (true);

-- Admin can delete users
CREATE POLICY "Admin can delete users" ON users
  FOR DELETE USING (true);

-- ─── Class Assignments RLS ───────────────────────────────────────────────
CREATE POLICY "Anyone can read class assignments" ON class_assignments
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert class assignments" ON class_assignments
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update class assignments" ON class_assignments
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete class assignments" ON class_assignments
  FOR DELETE USING (true);

-- ─── Students RLS ─────────────────────────────────────────────────────────
-- Teachers can read students in assigned classes; admin reads all
CREATE POLICY "Anyone can read students" ON students
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert students" ON students
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update students" ON students
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete students" ON students
  FOR DELETE USING (true);

-- ─── Attendance RLS ──────────────────────────────────────────────────────
CREATE POLICY "Anyone can read attendance" ON attendance
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert attendance" ON attendance
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update attendance" ON attendance
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete attendance" ON attendance
  FOR DELETE USING (true);

-- ─── Homework RLS ────────────────────────────────────────────────────────
CREATE POLICY "Anyone can read homework" ON homework
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert homework" ON homework
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update homework" ON homework
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete homework" ON homework
  FOR DELETE USING (true);

-- ─── Homework Status RLS ─────────────────────────────────────────────────
CREATE POLICY "Anyone can read homework status" ON homework_status
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert homework status" ON homework_status
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update homework status" ON homework_status
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete homework status" ON homework_status
  FOR DELETE USING (true);

-- ─── Fees RLS ────────────────────────────────────────────────────────────
CREATE POLICY "Anyone can read fees" ON fees
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert fees" ON fees
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update fees" ON fees
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete fees" ON fees
  FOR DELETE USING (true);

-- ─── Notices RLS ─────────────────────────────────────────────────────────
CREATE POLICY "Anyone can read notices" ON notices
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert notices" ON notices
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update notices" ON notices
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete notices" ON notices
  FOR DELETE USING (true);

-- ─── Message Templates RLS ──────────────────────────────────────────────
CREATE POLICY "Anyone can read templates" ON message_templates
  FOR SELECT USING (true);

CREATE POLICY "Anyone can insert templates" ON message_templates
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Anyone can update templates" ON message_templates
  FOR UPDATE USING (true);

CREATE POLICY "Anyone can delete templates" ON message_templates
  FOR DELETE USING (true);

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SECTION 5: SEED DATA
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- NOTE: Password hashes are for demo purposes only.
-- admin123 → $2b$12$DypOzL2pGu6jK5kJgOQyIOdlsbW6V0m8leOGPpr5BIKkN0CVcvRaK
-- teacher123 → $2b$12$pO..I880uD1hZjgpI0nY6ulx2Fe8geQ07sJdlU.AlkJfyZz35DO5u
-- After running this, regenerate hashes with your app's bcrypt and update.
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

-- ─── Admin User ──────────────────────────────────────────────────────────
INSERT INTO users (id, email, password_hash, display_name, role, phone, is_active)
VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'admin@nemps',
  '$2b$12$DypOzL2pGu6jK5kJgOQyIOdlsbW6V0m8leOGPpr5BIKkN0CVcvRaK',
  'Principal',
  'admin',
  NULL,
  true
) ON CONFLICT (email) DO NOTHING;

-- ─── Demo Teacher ────────────────────────────────────────────────────────
INSERT INTO users (id, email, password_hash, display_name, role, phone, is_active)
VALUES (
  'a0000000-0000-0000-0000-000000000002',
  'teacher@nemps',
  '$2b$12$pO..I880uD1hZjgpI0nY6ulx2Fe8geQ07sJdlU.AlkJfyZz35DO5u',
  'Demo Teacher',
  'teacher',
  '+919999999999',
  true
) ON CONFLICT (email) DO NOTHING;

-- ─── Class Assignments ──────────────────────────────────────────────────
INSERT INTO class_assignments (user_id, class_name) VALUES
  ('a0000000-0000-0000-0000-000000000002', 'Nursery'),
  ('a0000000-0000-0000-0000-000000000002', '1st')
ON CONFLICT DO NOTHING;

-- ─── Demo Students (Nursery) ─────────────────────────────────────────────
INSERT INTO students (id, roll_no, student_name, father_name, mother_name, parent_whatsapp, dob, address, class_name) VALUES
  ('c0000000-0000-0000-0000-000000000001', '01', 'Aarav Sharma', 'Rajesh Sharma', 'Sunita Sharma', '+919876543210', '2020-03-15', 'Vrindavan', 'Nursery'),
  ('c0000000-0000-0000-0000-000000000002', '02', 'Priya Gupta', 'Mohan Gupta', 'Rekha Gupta', '+919876543211', '2020-05-20', 'Vrindavan', 'Nursery'),
  ('c0000000-0000-0000-0000-000000000003', '03', 'Rohan Kumar', 'Suresh Kumar', 'Anita Kumar', '+919876543212', '2020-01-10', 'Mathura', 'Nursery'),
  ('c0000000-0000-0000-0000-000000000004', '04', 'Ananya Singh', 'Vikram Singh', 'Pooja Singh', '+919876543213', '2020-07-25', 'Vrindavan', 'Nursery'),
  ('c0000000-0000-0000-0000-000000000005', '05', 'Arjun Yadav', 'Ramesh Yadav', 'Kavita Yadav', '+919876543214', '2020-11-08', 'Vrindavan', 'Nursery')
ON CONFLICT DO NOTHING;

-- ─── Demo Students (1st) ─────────────────────────────────────────────────
INSERT INTO students (id, roll_no, student_name, father_name, mother_name, parent_whatsapp, dob, address, class_name) VALUES
  ('c0000000-0000-0000-0000-000000000006', '01', 'Meera Patel', 'Dinesh Patel', 'Hema Patel', '+919876543215', '2018-06-12', 'Vrindavan', '1st'),
  ('c0000000-0000-0000-0000-000000000007', '02', 'Krishna Verma', 'Arun Verma', 'Sarita Verma', '+919876543216', '2018-09-03', 'Mathura', '1st'),
  ('c0000000-0000-0000-0000-000000000008', '03', 'Sita Sharma', 'Ravi Sharma', 'Geeta Sharma', '+919876543217', '2018-02-28', 'Vrindavan', '1st')
ON CONFLICT DO NOTHING;

-- ─── Notices ─────────────────────────────────────────────────────────────
INSERT INTO notices (id, title, body, category, class_name, notice_date, created_by, is_active) VALUES
  ('d0000000-0000-0000-0000-000000000001', 'Annual Day Celebration', 'Dear Parents, our Annual Day will be celebrated on 25th January. All students must participate. Please ensure your ward is present.', 'General', NULL, '2025-01-20', 'a0000000-0000-0000-0000-000000000001', true),
  ('d0000000-0000-0000-0000-000000000002', 'Unit Test Schedule', 'Unit test for class Nursery will be held from 1st February. Please prepare well.', 'Exam', 'Nursery', '2025-01-22', 'a0000000-0000-0000-0000-000000000001', true)
ON CONFLICT DO NOTHING;

-- ─── Message Templates (Bilingual: English + Hindi) ─────────────────────
INSERT INTO message_templates (id, template_key, title, body_en, body_hi, is_active, created_by) VALUES
  (
    'b0000000-0000-0000-0000-000000000001',
    'absent_student',
    'Absent Student',
    'Dear Parent, your child {student_name} of class {class_name} was absent on {date}. Please ensure regular attendance. - {school_name}',
    'प्रिय अभिभावक, आपका बच्चा {student_name} कक्षा {class_name} का {date} को अनुपस्थित था। कृपया नियमित उपस्थिति सुनिश्चित करें। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000002',
    'homework_pending',
    'Homework Pending',
    'Dear Parent, {student_name} of class {class_name} has pending homework. Please ensure completion. - {school_name}',
    'प्रिय अभिभावक, {student_name} कक्षा {class_name} का होमवर्क बाकी है। कृपया पूरा करवाएं। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000003',
    'fee_due',
    'Fee Due Reminder',
    'Dear Parent, fee of ₹{amount} for {fee_month} is due for {student_name} of class {class_name}. Please pay before due date. - {school_name}',
    'प्रिय अभिभावक, {student_name} कक्षा {class_name} की {fee_month} की फीस ₹{amount} बकाया है। कृपया अंतिम तिथि से पहले जमा करें। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000004',
    'general_notice',
    'General Notice',
    'Dear Parent, {school_name} would like to inform you about an important notice for class {class_name} on {date}. - {school_name}',
    'प्रिय अभिभावक, {school_name} सूचित करना चाहता है: {date} - कक्षा {class_name} के लिए महत्वपूर्ण सूचना। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000005',
    'ptm_notice',
    'PTM Notice',
    'Dear Parent, Parent-Teacher Meeting for class {class_name} is scheduled on {date}. Please attend. - {school_name}',
    'प्रिय अभिभावक, कक्षा {class_name} की अभिभावक-शिक्षक बैठक {date} को निर्धारित है। कृपया उपस्थित रहें। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  )
ON CONFLICT (template_key) DO NOTHING;

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SECTION 6: FUNCTIONS & TRIGGERS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_students_updated_at ON students;
CREATE TRIGGER update_students_updated_at BEFORE UPDATE ON students FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_fees_updated_at ON fees;
CREATE TRIGGER update_fees_updated_at BEFORE UPDATE ON fees FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_notices_updated_at ON notices;
CREATE TRIGGER update_notices_updated_at BEFORE UPDATE ON notices FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS update_templates_updated_at ON message_templates;
CREATE TRIGGER update_templates_updated_at BEFORE UPDATE ON message_templates FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- DONE! ✅ Your NEMPS database is ready.
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
