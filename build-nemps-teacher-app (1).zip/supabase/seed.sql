-- ════════════════════════════════════════════════════════════════════════
-- NEMPS Teacher Assistant - Database Seed
-- New Era Modern Public School, Vrindavan
-- ════════════════════════════════════════════════════════════════════════

-- Seed admin user (password: admin123)
-- bcrypt hash for 'admin123' with 12 rounds
INSERT INTO users (id, email, password_hash, display_name, role, phone, is_active)
VALUES (
  'a0000000-0000-0000-0000-000000000001',
  'admin@nemps',
  '$2a$12$LJ3m4ys3Lk0TSwMCfVSLnOXLwHbONbKxHPOR3lEVbwGH6qFvWVP2S',
  'Principal',
  'admin',
  NULL,
  true
) ON CONFLICT (email) DO NOTHING;

-- Seed demo teacher (password: teacher123)
INSERT INTO users (id, email, password_hash, display_name, role, phone, is_active)
VALUES (
  'a0000000-0000-0000-0000-000000000002',
  'teacher@nemps',
  '$2a$12$LJ3m4ys3Lk0TSwMCfVSLnOXLwHbONbKxHPOR3lEVbwGH6qFvWVP2S',
  'Demo Teacher',
  'teacher',
  '+919999999999',
  true
) ON CONFLICT (email) DO NOTHING;

-- Assign demo teacher to Nursery and 1st class
INSERT INTO class_assignments (user_id, class_name)
VALUES
  ('a0000000-0000-0000-0000-000000000002', 'Nursery'),
  ('a0000000-0000-0000-0000-000000000002', '1st')
ON CONFLICT DO NOTHING;

-- Seed message templates
INSERT INTO message_templates (id, template_key, title, body_en, body_hi, is_active, created_by)
VALUES
  (
    'b0000000-0000-0000-0000-000000000001',
    'absent_student',
    'Absent Student',
    'Dear Parent, your child {student_name} of class {class_name} was absent on {date}. Please ensure regular attendance. - {school_name}',
    'प्रिय अभिभावक, आपका बच्चा {student_name} कक्षा {class_name} का {date} को अनुपस्थित था। कृपया नियमित उपस्थिति सुनिश्चित करें। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000002',
    'homework_pending',
    'Homework Pending',
    'Dear Parent, {student_name} of class {class_name} has pending homework. Please ensure completion. - {school_name}',
    'प्रिय अभिभावक, {student_name} कक्षा {class_name} का होमवर्क बाकी है। कृपया पूरा करवाएं। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000003',
    'fee_due',
    'Fee Due Reminder',
    'Dear Parent, fee of ₹{amount} for {fee_month} is due for {student_name} of class {class_name}. Please pay before due date. - {school_name}',
    'प्रिय अभिभावक, {student_name} कक्षा {class_name} की {fee_month} की फीस ₹{amount} बकाया है। कृपया अंतिम तिथि से पहले जमा करें। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000004',
    'general_notice',
    'General Notice',
    'Dear Parent, {school_name} would like to inform: {date} - Important notice for class {class_name}. - {school_name}',
    'प्रिय अभिभावक, {school_name} सूचित करना चाहता है: {date} - कक्षा {class_name} के लिए महत्वपूर्ण सूचना। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  ),
  (
    'b0000000-0000-0000-0000-000000000005',
    'ptm_notice',
    'PTM Notice',
    'Dear Parent, Parent-Teacher Meeting for class {class_name} is scheduled on {date}. Please attend. - {school_name}',
    'प्रिय अभिभावक, कक्षा {class_name} की अभिभावक-शिक्षक बैठक {date} को निर्धारित है। कृपया उपस्थित रहें। - {school_name}',
    true,
    'a0000000-0000-0000-0000-000000000001'
  )
ON CONFLICT (template_key) DO NOTHING;
