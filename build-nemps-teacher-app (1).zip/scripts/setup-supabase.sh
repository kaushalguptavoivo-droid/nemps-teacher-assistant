#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# NEMPS Teacher Assistant — Setup Script
# Run this after cloning the repo to set up everything
# ═══════════════════════════════════════════════════════════════════════════

set -e

echo "🏫 NEMPS Teacher Assistant — Setup"
echo "═══════════════════════════════════════"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org"
  exit 1
fi
echo "✅ Node.js $(node -v)"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
npm install

# Check for .env
if [ ! -f .env ]; then
  echo ""
  echo "📝 Creating .env from .env.example..."
  cp .env.example .env
  echo "⚠️  Edit .env with your DATABASE_URL and JWT_SECRET before proceeding"
  echo "   For local dev: DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db"
  echo "   For Supabase:  DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@db.xxx.supabase.co:5432/postgres"
  echo ""
  read -p "Press Enter after updating .env, or Ctrl+C to exit..."
fi

# Generate JWT_SECRET if not set
if grep -q "nemps-teacher-assistant-secret-key-2024" .env; then
  JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  if [[ "$OSTYPE" == "darwin"* ]]; then
    sed -i '' "s/nemps-teacher-assistant-secret-key-2024/$JWT_SECRET/" .env
  else
    sed -i "s/nemps-teacher-assistant-secret-key-2024/$JWT_SECRET/" .env
  fi
  echo "🔐 Generated JWT_SECRET in .env"
fi

# Push schema
echo ""
echo "🗄️  Pushing database schema..."
npx drizzle-kit push

# Generate password hashes
echo ""
echo "🔑 Generating password hashes..."
HASHES=$(node -e "
const bcrypt = require('bcryptjs');
async function main() {
  const h1 = await bcrypt.hash('admin123', 12);
  const h2 = await bcrypt.hash('teacher123', 12);
  console.log(h1 + '|' + h2);
}
main();
")
ADMIN_HASH=$(echo $HASHES | cut -d'|' -f1)
TEACHER_HASH=$(echo $HASHES | cut -d'|' -f2)

echo "   Admin hash: ${ADMIN_HASH:0:20}..."
echo "   Teacher hash: ${TEACHER_HASH:0:20}..."

# Get DATABASE_URL from .env
DB_URL=$(grep DATABASE_URL .env | cut -d'=' -f2-)

# Update password hashes in database
echo ""
echo "🔐 Updating password hashes in database..."
psql "$DB_URL" -c "UPDATE users SET password_hash = '$ADMIN_HASH' WHERE email = 'admin@nemps';" 2>/dev/null || \
  echo "⚠️  Could not update admin password. Run manually:"
echo "   UPDATE users SET password_hash = '$ADMIN_HASH' WHERE email = 'admin@nemps';"
echo "   UPDATE users SET password_hash = '$TEACHER_HASH' WHERE email = 'teacher@nemps';"

# Build
echo ""
echo "🔨 Building project..."
npm run build

echo ""
echo "═══════════════════════════════════════"
echo "✅ Setup complete!"
echo ""
echo "🔑 Login Credentials:"
echo "   Admin:   admin@nemps / admin123"
echo "   Teacher: teacher@nemps / teacher123"
echo ""
echo "🚀 Run with: npm run dev"
echo "🌐 Open: http://localhost:3000"
echo "═══════════════════════════════════════"
