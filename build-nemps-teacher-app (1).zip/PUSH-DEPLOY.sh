#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
# 🏫 NEMPS Teacher Assistant — ONE-COMMAND PUSH & DEPLOY
# ═══════════════════════════════════════════════════════════════════════════
# 
# YE FILE APNE LAPTOP/PC PE CHALAO (sandbox me nahi chalega)
# 
# PEHLE YE INSTALL KARO:
#   1. Git: https://git-scm.com/downloads
#   2. Node.js: https://nodejs.org
#   3. Vercel CLI: npm i -g vercel
#
# PHIR YE STEPS:
#   Step 1: GitHub pe repo banao → https://github.com/new
#           Name: nemps-teacher-assistant
#           DO NOT add README/gitignore/license (already hai)
#           Copy repo URL
#
#   Step 2: Supabase pe project banao → https://supabase.com/dashboard
#           Password: Kaushal@2024
#           Region: Mumbai
#           SQL Editor me supabase/schema.sql paste karke Run karo
#           Settings → Database → Connection string copy karo
#
#   Step 3: Ye script run karo:
#           chmod +x PUSH-DEPLOY.sh
#           ./PUSH-DEPLOY.sh
#
# ═══════════════════════════════════════════════════════════════════════════

set -e

echo ""
echo "🏫 NEMPS Teacher Assistant — Push & Deploy"
echo "═════════════════════════════════════════════════"
echo ""

# ── GitHub Repo URL ─────────────────────────────────────────────────────
read -p "🔧 GitHub repo URL (e.g. https://github.com/USERNAME/nemps-teacher-assistant.git): " REPO_URL

if [ -z "$REPO_URL" ]; then
  echo "❌ Repo URL is required!"
  exit 1
fi

# ── Database URL ────────────────────────────────────────────────────────
read -p "🗄️  Supabase DATABASE_URL: " DB_URL

if [ -z "$DB_URL" ]; then
  echo "❌ DATABASE_URL is required!"
  exit 1
fi

# ── JWT Secret ──────────────────────────────────────────────────────────
JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
echo "🔐 Generated JWT_SECRET: $JWT_SECRET"

# ── Update .env ─────────────────────────────────────────────────────────
echo "DATABASE_URL=$DB_URL" > .env
echo "JWT_SECRET=$JWT_SECRET" >> .env
echo "✅ .env updated"

# ── Git Setup ───────────────────────────────────────────────────────────
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO_URL"
echo "✅ Git remote set: $REPO_URL"

# ── Push to GitHub ──────────────────────────────────────────────────────
echo ""
echo "📤 Pushing to GitHub..."
git push -u origin main
echo "✅ Pushed to GitHub!"

# ── Update password hashes in Supabase ──────────────────────────────────
echo ""
echo "🔑 Generating password hashes..."
HASHES=$(node -e "
const bcrypt = require('bcryptjs');
async function main() {
  const h1 = await bcrypt.hash('admin123', 12);
  const h2 = await bcrypt.hash('teacher123', 12);
  console.log(h1 + '|' + h2);
}
main();
")
ADMIN_HASH=$(echo $HASHES | cut -d'|' -f1)
TEACHER_HASH=$(echo $HASHES | cut -d'|' -f2)

echo ""
echo "⚠️  AB SUPABASE SQL EDITOR ME YE SQL RUN KARO:"
echo "═══════════════════════════════════════════════"
echo "UPDATE users SET password_hash = '$ADMIN_HASH' WHERE email = 'admin@nemps';"
echo "UPDATE users SET password_hash = '$TEACHER_HASH' WHERE email = 'teacher@nemps';"
echo "═══════════════════════════════════════════════"
echo ""

# ── Vercel Deploy ───────────────────────────────────────────────────────
echo "🚀 Deploying to Vercel..."
echo ""
vercel login
vercel --yes

echo ""
echo "🌐 Vercel me Environment Variables set karo:"
echo "   DATABASE_URL = $DB_URL"
echo "   JWT_SECRET = $JWT_SECRET"
echo ""
echo "   Vercel Dashboard → Settings → Environment Variables → Add"
echo ""
echo "Then redeploy:"
echo "   vercel --prod"
echo ""

echo "═══════════════════════════════════════════════"
echo "✅ DONE! App is ready!"
echo ""
echo "🔑 Login:"
echo "   Admin:   admin@nemps / admin123"
echo "   Teacher: teacher@nemps / teacher123"
echo ""
echo "📱 Android: Chrome → Menu → Add to Home Screen"
echo "═══════════════════════════════════════════════"
